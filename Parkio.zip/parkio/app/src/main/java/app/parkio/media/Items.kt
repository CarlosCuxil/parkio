package app.parkio.media

import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import app.parkio.data.Episode

fun folderItem(id: String, title: String, art: String = ""): MediaItem =
    MediaItem.Builder()
        .setMediaId(id)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setIsBrowsable(true)
                .setIsPlayable(false)
                .setMediaType(MediaMetadata.MEDIA_TYPE_FOLDER_MIXED)
                .apply { if (art.isNotEmpty()) setArtworkUri(Uri.parse(art)) }
                .build()
        )
        .build()

fun Episode.toMediaItem(): MediaItem =
    MediaItem.Builder()
        .setMediaId(audioUrl)
        .setUri(audioUrl)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(podcast)
                .setAlbumTitle(podcast)
                .setIsBrowsable(false)
                .setIsPlayable(true)
                .setMediaType(MediaMetadata.MEDIA_TYPE_PODCAST_EPISODE)
                .apply { if (art.isNotEmpty()) setArtworkUri(Uri.parse(art)) }
                .build()
        )
        .build()

fun MediaItem.toEpisode(): Episode = Episode(
    audioUrl = mediaId,
    title = mediaMetadata.title?.toString().orEmpty(),
    podcast = mediaMetadata.artist?.toString().orEmpty(),
    art = mediaMetadata.artworkUri?.toString().orEmpty(),
    duration = "",
)
