package app.parkio

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.lifecycle.lifecycleScope
import app.parkio.data.Auth
import app.parkio.ui.AppViewModel
import app.parkio.ui.ParkioRoot
import app.parkio.ui.ParkioTheme
import com.google.android.gms.auth.api.identity.Identity
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val vm: AppViewModel by viewModels()

    private val authLauncher =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
            val data = res.data ?: return@registerForActivityResult
            try {
                val result = Identity.getAuthorizationClient(this).getAuthorizationResultFromIntent(data)
                if (Auth.accept(this, result)) vm.onSignedIn()
            } catch (e: Exception) {
                toast("No se pudo iniciar sesión: ${e.message}")
            }
        }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // La ubicación solo se usa para saber si el carro está detenido (video únicamente estacionado).
        // Ubicación: ver si el carro está detenido. Notificaciones: control del podcast en la pantalla de bloqueo.
        val wanted = buildList {
            add(Manifest.permission.ACCESS_FINE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (wanted.isNotEmpty()) permissionLauncher.launch(wanted.toTypedArray())
        setContent {
            ParkioTheme {
                ParkioRoot(vm, ::signIn)
            }
        }
    }

    private fun signIn() {
        lifecycleScope.launch {
            try {
                val result = Auth.authorize(this@MainActivity)
                val pending = result.pendingIntent
                if (result.hasResolution() && pending != null) {
                    authLauncher.launch(IntentSenderRequest.Builder(pending.intentSender).build())
                } else if (Auth.accept(this@MainActivity, result)) {
                    vm.onSignedIn()
                }
            } catch (e: Exception) {
                toast("No se pudo iniciar sesión: ${e.message}")
            }
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
