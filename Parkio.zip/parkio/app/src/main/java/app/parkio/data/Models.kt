package app.parkio.data

import org.json.JSONArray
import org.json.JSONObject
import java.time.Duration
import java.time.Instant

data class Video(
    val id: String,
    val title: String,
    val channel: String,
    val channelId: String,
    val thumb: String,
    val duration: String,
    val published: String,
    val publishedAt: String,
)

sealed interface Load<out T> {
    data object Idle : Load<Nothing>
    data object Loading : Load<Nothing>
    data class Ok<out T>(val value: T) : Load<T>
    data class Err(val message: String) : Load<Nothing>
}

fun List<Video>.toJsonArray(): JSONArray {
    val arr = JSONArray()
    forEach { v ->
        arr.put(
            JSONObject()
                .put("id", v.id)
                .put("title", v.title)
                .put("channel", v.channel)
                .put("thumb", v.thumb)
                .put("duration", v.duration)
                .put("published", v.published)
        )
    }
    return arr
}

/** "PT1H2M3S" -> "1:02:03". Vacío si no hay duración (por ejemplo en vivo). */
fun formatDuration(iso: String): String {
    if (iso.isEmpty()) return ""
    val total = try {
        Duration.parse(iso).seconds
    } catch (e: Exception) {
        return ""
    }
    if (total <= 0) return ""
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

fun relativeTime(iso: String): String = try {
    val mins = Duration.between(Instant.parse(iso), Instant.now()).toMinutes().coerceAtLeast(0)
    when {
        mins < 60 -> "hace unos minutos"
        mins < 60 * 24 -> plural(mins / 60, "hora")
        mins < 60 * 24 * 30 -> plural(mins / (60 * 24), "día")
        mins < 60 * 24 * 365 -> plural(mins / (60 * 24 * 30), "mes", "meses")
        else -> plural(mins / (60 * 24 * 365), "año")
    }
} catch (e: Exception) {
    ""
}

private fun plural(n: Long, one: String, many: String = one + "s"): String =
    "hace $n ${if (n == 1L) one else many}"
