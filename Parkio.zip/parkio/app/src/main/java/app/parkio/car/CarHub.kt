package app.parkio.car

import androidx.car.app.CarContext

/** Estado compartido de la sesión del carro: ¿está estacionado? (lo decide ParkGuard). */
class CarHub(ctx: CarContext) {

    var parked = false
        private set
    var canConfirm = false
        private set

    private val listeners = LinkedHashSet<() -> Unit>()

    private val guard = ParkGuard(ctx) { p, c ->
        parked = p
        canConfirm = c
        CarLog.add("Estacionado=$p, puede confirmar a mano=$c")
        listeners.toList().forEach { it() }
    }

    fun start() = guard.start()
    fun stop() = guard.stop()
    fun confirmManual() = guard.confirmManual()

    fun addListener(l: () -> Unit) {
        listeners.add(l)
    }

    fun removeListener(l: () -> Unit) {
        listeners.remove(l)
    }
}
