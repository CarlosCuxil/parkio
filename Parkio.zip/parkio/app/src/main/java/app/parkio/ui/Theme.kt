package app.parkio.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Pk {
    val Bg = Color(0xFF0E1013)
    val Surface = Color(0xFF171A1F)
    val Surface2 = Color(0xFF1C2027)
    val Line = Color(0xFF232831)
    val Text = Color(0xFFF2F4F7)
    val TextSoft = Color(0xFFD6DBE1)
    val Sub = Color(0xFF9AA3AE)
    val Accent = Color(0xFFFFB020)
    val OnAccent = Color(0xFF1A1200)
    val Ok = Color(0xFF4DD6B0)
    val Chan = Color(0xFF3B4F78)
}

@Composable
fun ParkioTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Pk.Accent,
            onPrimary = Pk.OnAccent,
            background = Pk.Bg,
            onBackground = Pk.Text,
            surface = Pk.Surface,
            onSurface = Pk.Text,
            surfaceVariant = Pk.Surface2,
            onSurfaceVariant = Pk.Sub,
            outline = Pk.Line,
        ),
        content = content,
    )
}
