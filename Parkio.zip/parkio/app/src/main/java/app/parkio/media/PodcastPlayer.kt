package app.parkio.media

import android.content.ComponentName
import android.content.Context
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import app.parkio.data.Episode
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.flow.MutableStateFlow

/** Control remoto del teléfono sobre el mismo servicio que usa Android Auto. */
object PodcastPlayer {
    private var future: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null

    val active = MutableStateFlow(false)
    val playing = MutableStateFlow(false)
    val title = MutableStateFlow("")
    val artist = MutableStateFlow("")

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            playing.value = isPlaying
        }

        override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
            sync(mediaMetadata)
        }
    }

    private fun sync(m: MediaMetadata) {
        title.value = m.title?.toString().orEmpty()
        artist.value = m.artist?.toString().orEmpty()
        active.value = title.value.isNotEmpty()
    }

    fun connect(ctx: Context) {
        if (future != null) return
        val app = ctx.applicationContext
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val f = MediaController.Builder(app, token).buildAsync()
        future = f
        f.addListener({
            val c = f.get()
            controller = c
            c.addListener(listener)
            playing.value = c.isPlaying
            sync(c.mediaMetadata)
        }, ContextCompat.getMainExecutor(app))
    }

    private fun withController(ctx: Context, block: (MediaController) -> Unit) {
        connect(ctx)
        val f = future ?: return
        f.addListener({ block(f.get()) }, ContextCompat.getMainExecutor(ctx.applicationContext))
    }

    fun play(ctx: Context, ep: Episode) = withController(ctx) { c ->
        c.setMediaItem(ep.toMediaItem())
        c.prepare()
        c.play()
    }

    fun toggle(ctx: Context) = withController(ctx) { c -> if (c.isPlaying) c.pause() else c.play() }
    fun back(ctx: Context) = withController(ctx) { it.seekBack() }
    fun forward(ctx: Context) = withController(ctx) { it.seekForward() }
}
