package app.parkio.data

import android.content.Context
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.tasks.await

/**
 * Inicio de sesión con Google. Parkio nunca ve la contraseña: Google entrega solo un token de acceso
 * con permiso para la API de YouTube (ver suscripciones, listas, dar me gusta, suscribirse).
 */
object Auth {
    private const val SCOPE = "https://www.googleapis.com/auth/youtube"
    private const val PREFS = "parkio_auth"
    private const val TOKEN_LIFETIME_MS = 50 * 60 * 1000L

    private var token: String? = null
    private var expiresAt = 0L

    fun isSignedIn(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("signed_in", false)

    private fun request(): AuthorizationRequest =
        AuthorizationRequest.builder().setRequestedScopes(listOf(Scope(SCOPE))).build()

    suspend fun authorize(ctx: Context): AuthorizationResult =
        Identity.getAuthorizationClient(ctx).authorize(request()).await()

    fun accept(ctx: Context, result: AuthorizationResult): Boolean {
        val t = result.accessToken ?: return false
        token = t
        expiresAt = System.currentTimeMillis() + TOKEN_LIFETIME_MS
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("signed_in", true).apply()
        return true
    }

    /** Token sin pantallas. Devuelve null si no hay sesión o si Google pide volver a aceptar permisos. */
    suspend fun silentToken(ctx: Context): String? {
        if (!isSignedIn(ctx)) return null
        val cached = token
        if (cached != null && System.currentTimeMillis() < expiresAt) return cached
        return try {
            val r = authorize(ctx)
            if (r.hasResolution() || !accept(ctx, r)) null else r.accessToken
        } catch (e: Exception) {
            null
        }
    }

    fun signOut(ctx: Context) {
        token = null
        expiresAt = 0
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("signed_in", false).apply()
    }
}
