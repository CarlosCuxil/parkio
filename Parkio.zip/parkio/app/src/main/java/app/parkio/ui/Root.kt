package app.parkio.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Podcasts
import androidx.compose.material.icons.filled.Subscriptions
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle

private data class Tab(val label: String, val icon: ImageVector)

private val TABS = listOf(
    Tab("Inicio", Icons.Filled.Home),
    Tab("Explorar", Icons.Filled.Explore),
    Tab("Suscr.", Icons.Filled.Subscriptions),
    Tab("Podcasts", Icons.Filled.Podcasts),
    Tab("Biblioteca", Icons.Filled.VideoLibrary),
)

@Composable
fun ParkioRoot(vm: AppViewModel, onSignIn: () -> Unit) {
    val ctx = LocalContext.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val current by vm.current.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        vm.message.collect { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show() }
    }

    Box(Modifier.fillMaxSize().background(Pk.Bg)) {
        Scaffold(
            containerColor = Pk.Bg,
            bottomBar = {
                Column {
                PodcastMiniBar()
                NavigationBar(containerColor = Pk.Bg) {
                    TABS.forEachIndexed { i, t ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Icon(t.icon, contentDescription = null) },
                            label = { Text(t.label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Pk.Accent,
                                selectedTextColor = Pk.Accent,
                                indicatorColor = Pk.Surface2,
                                unselectedIconColor = Pk.Sub,
                                unselectedTextColor = Pk.Sub,
                            ),
                        )
                    }
                }
                }
            },
        ) { pad ->
            Box(Modifier.padding(pad)) {
                when (tab) {
                    0 -> HomeScreen(vm, onSignIn)
                    1 -> ExploreScreen(vm)
                    2 -> SubsScreen(vm, onSignIn)
                    3 -> PodcastsScreen()
                    else -> LibraryScreen(vm, onSignIn)
                }
            }
        }
        current?.let { PlayerScreen(it, vm) }
    }
}
