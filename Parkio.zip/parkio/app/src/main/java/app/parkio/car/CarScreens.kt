package app.parkio.car

import android.content.Context
import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.constraints.ConstraintManager
import androidx.car.app.model.Action
import androidx.car.app.model.ItemList
import androidx.car.app.model.ListTemplate
import androidx.car.app.model.MessageTemplate
import androidx.car.app.model.Row
import androidx.car.app.model.Template
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import app.parkio.ParkioApp
import app.parkio.data.Video
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Cuántas filas deja mostrar el carro en una lista (menos cuando va en marcha). */
private fun listLimit(ctx: CarContext): Int = try {
    ctx.getCarService(ConstraintManager::class.java)
        .getContentLimit(ConstraintManager.CONTENT_LIMIT_TYPE_LIST)
} catch (e: Exception) {
    6
}

/** Menú principal. Todo se maneja con la perilla del carro. */
class HomeScreen(ctx: CarContext, private val hub: CarHub) : Screen(ctx) {

    private val onHub: () -> Unit = { invalidate() }

    init {
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onCreate(owner: LifecycleOwner) {
                hub.addListener(onHub)
            }

            override fun onDestroy(owner: LifecycleOwner) {
                hub.removeListener(onHub)
            }
        })
    }

    override fun onGetTemplate(): Template {
        val state = when {
            hub.parked -> "Estacionado: el video está habilitado"
            hub.canConfirm -> "Sin señal de GPS: confirma que estás estacionado al elegir un video"
            else -> "En marcha: el video está bloqueado"
        }
        val list = ItemList.Builder()
            .addItem(Row.Builder().setTitle(state).build())
            .addItem(
                Row.Builder().setTitle("Cola del carro").addText("Videos que enviaste desde el teléfono")
                    .setBrowsable(true)
                    .setOnClickListener { screenManager.push(FeedScreen(carContext, hub, "queue", "Cola del carro")) }
                    .build()
            )
            .addItem(
                Row.Builder().setTitle("Suscripciones").addText("Lo más nuevo de tus canales")
                    .setBrowsable(true)
                    .setOnClickListener { screenManager.push(FeedScreen(carContext, hub, "subs", "Suscripciones")) }
                    .build()
            )
            .addItem(
                Row.Builder().setTitle("Populares").addText("Videos en tendencia")
                    .setBrowsable(true)
                    .setOnClickListener { screenManager.push(FeedScreen(carContext, hub, "popular", "Populares")) }
                    .build()
            )
            .addItem(
                Row.Builder().setTitle("Prueba de pantalla").addText("Barras animadas con FPS")
                    .setBrowsable(true)
                    .setOnClickListener { screenManager.push(TestScreen(carContext)) }
                    .build()
            )
            .addItem(
                Row.Builder().setTitle("Diagnóstico").addText("Qué pasa por dentro si algo no se ve")
                    .setBrowsable(true)
                    .setOnClickListener { screenManager.push(DiagScreen(carContext, hub)) }
                    .build()
            )
            .build()
        return ListTemplate.Builder()
            .setSingleList(list)
            .setTitle("Parkio")
            .setHeaderAction(Action.APP_ICON)
            .build()
    }
}

/** Lista de videos (cola, suscripciones o populares). Elegir uno lo abre solo si el carro está estacionado. */
class FeedScreen(
    ctx: CarContext,
    private val hub: CarHub,
    private val kind: String,
    private val title: String,
) : Screen(ctx) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var items: List<Video>? = null
    private var error: String? = null

    init {
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onCreate(owner: LifecycleOwner) {
                load()
            }

            override fun onDestroy(owner: LifecycleOwner) {
                scope.cancel()
            }
        })
    }

    private fun load() {
        scope.launch {
            try {
                val app = ParkioApp.instance
                items = when (kind) {
                    "queue" -> app.carQueue.value
                    "subs" -> app.api.subscriptionsFeed()
                    else -> app.api.popular()
                }
            } catch (e: Exception) {
                error = (e.message ?: "").ifBlank { "Error de red" }
                CarLog.add("Error al cargar $kind: ${e.message}")
            }
            invalidate()
        }
    }

    private fun open(v: Video) {
        if (hub.parked) {
            screenManager.push(PlayerScreen(carContext, hub, v))
        } else {
            screenManager.push(LockedScreen(carContext, hub, v))
        }
    }

    override fun onGetTemplate(): Template {
        val err = error
        if (err != null) {
            return MessageTemplate.Builder(err).setTitle(title).setHeaderAction(Action.BACK).build()
        }
        val list = items
        if (list == null) {
            return ListTemplate.Builder().setLoading(true).setTitle(title).setHeaderAction(Action.BACK).build()
        }
        val empty = if (kind == "queue") {
            "La cola está vacía. Envía videos desde el teléfono con «Enviar al carro»."
        } else {
            "No hay videos para mostrar."
        }
        val b = ItemList.Builder().setNoItemsMessage(empty)
        list.take(listLimit(carContext)).forEach { v ->
            val sub = listOf(v.channel, v.duration).filter { it.isNotBlank() }.joinToString(" · ")
            val row = Row.Builder().setTitle(v.title.ifBlank { "(sin título)" })
            if (sub.isNotBlank()) row.addText(sub)
            row.setOnClickListener { open(v) }
            b.addItem(row.build())
        }
        return ListTemplate.Builder().setSingleList(b.build()).setTitle(title).setHeaderAction(Action.BACK).build()
    }
}

/** Aviso de video bloqueado. Si el carro queda estacionado (o lo confirmas sin GPS) abre el video solo. */
class LockedScreen(
    ctx: CarContext,
    private val hub: CarHub,
    private val video: Video,
) : Screen(ctx) {

    private val onHub: () -> Unit = {
        if (hub.parked) {
            screenManager.pop()
            screenManager.push(PlayerScreen(carContext, hub, video))
        } else {
            invalidate()
        }
    }

    init {
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onCreate(owner: LifecycleOwner) {
                hub.addListener(onHub)
            }

            override fun onDestroy(owner: LifecycleOwner) {
                hub.removeListener(onHub)
            }
        })
    }

    override fun onGetTemplate(): Template {
        val msg = if (hub.canConfirm) {
            "No hay señal de GPS. Si el carro está estacionado, confírmalo para ver el video."
        } else {
            "Parkio solo reproduce video con el carro detenido. Se desbloquea unos segundos después de estacionar."
        }
        val b = MessageTemplate.Builder(msg).setTitle("Video bloqueado").setHeaderAction(Action.BACK)
        if (hub.canConfirm) {
            b.addAction(
                Action.Builder().setTitle("Estoy estacionado").setOnClickListener { hub.confirmManual() }.build()
            )
        }
        return b.build()
    }
}

/** Registro interno para entender por qué algo no se ve. */
class DiagScreen(ctx: CarContext, private val hub: CarHub) : Screen(ctx) {

    private val prefs = ctx.getSharedPreferences("parkio", Context.MODE_PRIVATE)

    override fun onGetTemplate(): Template {
        val software = prefs.getBoolean("car_sw", false)
        val b = ItemList.Builder()
        b.addItem(
            Row.Builder()
                .setTitle("Actualizar registro")
                .addText(if (hub.parked) "Estacionado" else "En marcha o sin confirmar")
                .setOnClickListener { invalidate() }
                .build()
        )
        b.addItem(
            Row.Builder()
                .setTitle("Modo de dibujo: ${if (software) "compatible" else "normal"}")
                .addText("Pulsa para cambiarlo. Si la prueba de pantalla sale negra, prueba el otro modo.")
                .setOnClickListener {
                    prefs.edit().putBoolean("car_sw", !software).apply()
                    CarLog.add("Modo de dibujo cambiado a ${if (!software) "compatible" else "normal"}")
                    invalidate()
                }
                .build()
        )
        val room = (listLimit(carContext) - 2).coerceAtLeast(1)
        CarLog.last(room).forEach { line ->
            b.addItem(Row.Builder().setTitle(line).build())
        }
        return ListTemplate.Builder()
            .setSingleList(b.build())
            .setTitle("Diagnóstico")
            .setHeaderAction(Action.BACK)
            .build()
    }
}
