package app.parkio.car

import android.content.Intent
import androidx.car.app.CarAppService
import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.Session
import androidx.car.app.validation.HostValidator

/**
 * Punto de entrada de Android Auto. Se declara en la categoría NAVIGATION porque es la única
 * categoría de la Car App Library que entrega una superficie (Surface) donde dibujar.
 * Eso funciona para una app instalada a mano (APK) con "Fuentes desconocidas" activado en
 * los ajustes de desarrollador de Android Auto; Google Play no lo aceptaría para video.
 */
class ParkioCarAppService : CarAppService() {

    // App personal instalada por APK: se aceptan todos los hosts. No usar así en una app publicada.
    override fun createHostValidator(): HostValidator = HostValidator.ALLOW_ALL_HOSTS_VALIDATOR

    override fun onCreateSession(): Session = ParkioSession()
}

class ParkioSession : Session() {
    override fun onCreateScreen(intent: Intent): Screen = CarScreen(carContext)
}
