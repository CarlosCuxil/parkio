package app.parkio.car

import android.content.Intent
import androidx.car.app.CarAppService
import androidx.car.app.Screen
import androidx.car.app.Session
import androidx.car.app.validation.HostValidator
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner

/**
 * Punto de entrada de Android Auto. Se declara en la categoría NAVIGATION porque es la única
 * categoría de la Car App Library que entrega una superficie (Surface) donde dibujar el video.
 * Funciona para una app instalada a mano (APK) con "Fuentes desconocidas" activado en
 * los ajustes de desarrollador de Android Auto; Google Play no lo aceptaría para video.
 *
 * El Mazda Connect no usa la pantalla táctil con Android Auto: todo se maneja con la perilla
 * (Commander). Por eso los menús son plantillas nativas y el video lleva botones en la barra de acciones.
 */
class ParkioCarAppService : CarAppService() {

    // App personal instalada por APK: se aceptan todos los hosts. No usar así en una app publicada.
    override fun createHostValidator(): HostValidator = HostValidator.ALLOW_ALL_HOSTS_VALIDATOR

    override fun onCreateSession(): Session = ParkioSession()
}

class ParkioSession : Session() {

    private var hub: CarHub? = null

    override fun onCreateScreen(intent: Intent): Screen {
        val h = CarHub(carContext)
        hub = h
        h.start()
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onDestroy(owner: LifecycleOwner) {
                h.stop()
            }
        })
        CarLog.add("Sesión del carro creada")
        return HomeScreen(carContext, h)
    }
}
