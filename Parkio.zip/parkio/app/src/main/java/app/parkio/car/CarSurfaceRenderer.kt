package app.parkio.car

import android.annotation.SuppressLint
import android.app.Presentation
import android.content.Context
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Display
import android.view.MotionEvent
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.car.app.CarContext
import androidx.car.app.SurfaceCallback
import androidx.car.app.SurfaceContainer
import app.parkio.ParkioApp
import app.parkio.data.toJsonArray
import app.parkio.player.PlayerHtml
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * Dibuja la interfaz del carro (assets/car/index.html) en la superficie que entrega Android Auto:
 * VirtualDisplay -> Presentation -> WebView. Los toques del carro se reenvían al WebView.
 */
class CarSurfaceRenderer(private val carContext: CarContext) : SurfaceCallback {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val main = Handler(Looper.getMainLooper())

    private var virtualDisplay: VirtualDisplay? = null
    private var presentation: CarPresentation? = null

    private var lastParked = false
    private var lastCanConfirm = false

    private val guard = ParkGuard(carContext) { parked, canConfirm ->
        lastParked = parked
        lastCanConfirm = canConfirm
        pushState()
    }

    private fun pushState() {
        presentation?.evalJs("window.parkio&&parkio.setState($lastParked,$lastCanConfirm)")
    }

    /** Puente JS -> Kotlin. Solo expone lo mínimo: pedir listas de videos y confirmar estacionado. */
    inner class CarBridge {
        @JavascriptInterface
        fun ready() {
            main.post { pushState() }
        }

        @JavascriptInterface
        fun requestFeed(kind: String) {
            main.post { loadFeed(kind) }
        }

        @JavascriptInterface
        fun confirmParked() {
            main.post { guard.confirmManual() }
        }
    }

    override fun onSurfaceAvailable(surfaceContainer: SurfaceContainer) {
        val surface = surfaceContainer.surface ?: return
        releaseDisplay()
        val dm = carContext.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val vd = dm.createVirtualDisplay(
            "parkio-car",
            surfaceContainer.width,
            surfaceContainer.height,
            surfaceContainer.dpi,
            surface,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY or DisplayManager.VIRTUAL_DISPLAY_FLAG_PRESENTATION,
        )
        virtualDisplay = vd
        val html = carContext.assets.open("car/index.html").bufferedReader().use { it.readText() }
        val p = CarPresentation(carContext, vd.display, CarBridge(), html)
        p.show()
        presentation = p
        guard.start()
    }

    override fun onSurfaceDestroyed(surfaceContainer: SurfaceContainer) {
        guard.stop()
        releaseDisplay()
    }

    override fun onVisibleAreaChanged(visibleArea: Rect) {}
    override fun onStableAreaChanged(stableArea: Rect) {}
    override fun onFling(velocityX: Float, velocityY: Float) {}
    override fun onScale(focusX: Float, focusY: Float, scaleFactor: Float) {}

    override fun onClick(x: Float, y: Float) {
        presentation?.tap(x, y)
    }

    override fun onScroll(distanceX: Float, distanceY: Float) {
        presentation?.evalJs("window.parkioScroll&&parkioScroll($distanceX,$distanceY)")
    }

    private fun loadFeed(kind: String) {
        scope.launch {
            val payload = JSONObject()
            try {
                val app = ParkioApp.instance
                val items = when (kind) {
                    "queue" -> app.carQueue.value
                    "subs" -> app.api.subscriptionsFeed()
                    "popular" -> app.api.popular()
                    else -> emptyList()
                }
                payload.put("items", items.toJsonArray())
            } catch (e: Exception) {
                payload.put("error", e.message ?: "Error de red")
            }
            presentation?.evalJs(
                "parkioFeed(${JSONObject.quote(kind)}, ${JSONObject.quote(payload.toString())})"
            )
        }
    }

    private fun releaseDisplay() {
        presentation?.dismiss()
        presentation = null
        virtualDisplay?.release()
        virtualDisplay = null
    }

    fun release() {
        guard.stop()
        releaseDisplay()
        scope.cancel()
    }
}

class CarPresentation(
    ctx: Context,
    display: Display,
    private val bridge: Any,
    private val html: String,
) : Presentation(ctx, display) {

    private var web: WebView? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val w = WebView(context)
        w.setBackgroundColor(0xFF0E1013.toInt())
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.webChromeClient = WebChromeClient()
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = true
        }
        w.addJavascriptInterface(bridge, "Android")
        web = w
        setContentView(w)
        w.loadDataWithBaseURL(PlayerHtml.BASE_URL, html, "text/html", "utf-8", null)
    }

    override fun onStop() {
        web?.destroy()
        web = null
        super.onStop()
    }

    fun evalJs(js: String) {
        web?.post { web?.evaluateJavascript(js, null) }
    }

    /** Reenvía un toque del carro (coordenadas de la superficie) al WebView. */
    fun tap(x: Float, y: Float) {
        val w = web ?: return
        w.post {
            val t = SystemClock.uptimeMillis()
            val down = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, x, y, 0)
            w.dispatchTouchEvent(down)
            down.recycle()
            w.postDelayed({
                val up = MotionEvent.obtain(t, SystemClock.uptimeMillis(), MotionEvent.ACTION_UP, x, y, 0)
                w.dispatchTouchEvent(up)
                up.recycle()
            }, 60)
        }
    }
}
