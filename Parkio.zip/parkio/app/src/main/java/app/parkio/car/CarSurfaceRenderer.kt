package app.parkio.car

import android.annotation.SuppressLint
import android.app.Presentation
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.View
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView
import androidx.car.app.CarContext
import androidx.car.app.SurfaceCallback
import androidx.car.app.SurfaceContainer
import app.parkio.player.PlayerHtml

/**
 * Dibuja una página de assets/car/ en la superficie que entrega Android Auto:
 * VirtualDisplay -> Presentation -> WebView. No recibe toques (el Mazda no usa la pantalla táctil
 * con Android Auto); el control se hace con los botones de la plantilla y se manda a la página con [eval].
 */
class SurfaceRenderer(
    private val carContext: CarContext,
    private val asset: String,
    private val argument: String,
) : SurfaceCallback {

    private val main = Handler(Looper.getMainLooper())

    private var virtualDisplay: VirtualDisplay? = null
    private var presentation: CarPresentation? = null

    /** La página avisa si el video está reproduciéndose o en pausa. */
    var onPlaying: ((Boolean) -> Unit)? = null

    private var playerOk = false
    private var watchMode = false

    /** El reproductor incrustado avisa su etapa (api, ready, playing, error:CÓDIGO). */
    private fun handleStage(s: String) {
        CarLog.add("Etapa $s")
        if (s == "ready" || s == "playing") {
            playerOk = true
        } else if (s.startsWith("error:")) {
            fallbackToWeb("YouTube no deja el reproductor incrustado ($s)")
        }
    }

    /** Si el reproductor incrustado falla, se abre la web móvil de YouTube, que reproduce cualquier video público. */
    private fun fallbackToWeb(why: String) {
        if (watchMode || argument.isEmpty()) return
        watchMode = true
        CarLog.add("$why: cambio a la web de YouTube")
        presentation?.setStatus("Cambio a la web de YouTube")
        presentation?.loadWatch(argument)
    }

    /** Puente JS -> Kotlin. Solo lo mínimo. */
    inner class CarBridge {
        @JavascriptInterface
        fun ready() {
            main.post {
                CarLog.add("Página lista ($asset)")
                presentation?.setStatus("Página lista")
                main.postDelayed({ presentation?.setStatus(null) }, 8000)
                if (argument.isNotEmpty()) {
                    main.postDelayed({
                        if (!playerOk && !watchMode) fallbackToWeb("El reproductor incrustado no respondió en 9 s")
                    }, 9000)
                }
            }
        }

        @JavascriptInterface
        fun stage(s: String) {
            main.post { handleStage(s) }
        }

        @JavascriptInterface
        fun arg(): String = argument

        @JavascriptInterface
        fun playing(p: Boolean) {
            main.post { onPlaying?.invoke(p) }
        }

        @JavascriptInterface
        fun log(msg: String) {
            CarLog.add("JS: $msg")
        }
    }

    override fun onSurfaceAvailable(surfaceContainer: SurfaceContainer) {
        try {
            val surface = surfaceContainer.surface
            if (surface == null) {
                CarLog.add("Superficie nula")
                return
            }
            CarLog.add("Superficie ${surfaceContainer.width}x${surfaceContainer.height} @${surfaceContainer.dpi}dpi")
            releaseDisplay()
            playerOk = false
            watchMode = false
            val dm = carContext.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            val vd = dm.createVirtualDisplay(
                "parkio-car",
                surfaceContainer.width,
                surfaceContainer.height,
                surfaceContainer.dpi,
                surface,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY or DisplayManager.VIRTUAL_DISPLAY_FLAG_PRESENTATION,
            )
            if (vd == null) {
                CarLog.add("VirtualDisplay nulo")
                return
            }
            virtualDisplay = vd
            CarLog.add("VirtualDisplay creado")
            val html = carContext.assets.open(asset).bufferedReader().use { it.readText() }
            val software = carContext.getSharedPreferences("parkio", Context.MODE_PRIVATE)
                .getBoolean("car_sw", false)
            val p = CarPresentation(carContext, vd.display, CarBridge(), html, software)
            p.show()
            presentation = p
            CarLog.add("Presentation mostrada (modo ${if (software) "compatible" else "normal"})")
        } catch (e: Exception) {
            CarLog.add("ERROR al dibujar: ${e.javaClass.simpleName} ${e.message}")
        }
    }

    override fun onSurfaceDestroyed(surfaceContainer: SurfaceContainer) {
        CarLog.add("Superficie destruida")
        releaseDisplay()
    }

    override fun onVisibleAreaChanged(visibleArea: android.graphics.Rect) {}
    override fun onStableAreaChanged(stableArea: android.graphics.Rect) {}
    override fun onFling(velocityX: Float, velocityY: Float) {}
    override fun onScale(focusX: Float, focusY: Float, scaleFactor: Float) {}
    override fun onClick(x: Float, y: Float) {}
    override fun onScroll(distanceX: Float, distanceY: Float) {}

    /** Ejecuta JavaScript en la página. */
    fun eval(js: String) {
        presentation?.evalJs(js)
    }

    // Controles que sirven con el reproductor incrustado (window.parkio) y con la web de YouTube (<video>).
    fun play() = eval("(function(){var v=document.querySelector('video');if(v){v.play();}else if(window.parkio){parkio.play();}})()")

    fun pause() = eval("(function(){var v=document.querySelector('video');if(v){v.pause();}else if(window.parkio){parkio.pause();}})()")

    fun seek(seconds: Int) = eval(
        "(function(d){var v=document.querySelector('video');if(v){v.currentTime=Math.max(0,v.currentTime+d);}" +
            "else if(window.parkio){parkio.seek(d);}})($seconds)"
    )

    private fun releaseDisplay() {
        try {
            presentation?.dismiss()
        } catch (e: Exception) {
        }
        presentation = null
        virtualDisplay?.release()
        virtualDisplay = null
    }

    fun release() {
        releaseDisplay()
    }
}

class CarPresentation(
    ctx: Context,
    display: Display,
    private val bridge: Any,
    private val html: String,
    private val software: Boolean,
) : Presentation(ctx, display) {

    private var web: WebView? = null
    private var status: TextView? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(context)
        root.setBackgroundColor(Color.BLACK)

        val w = WebView(context)
        w.setBackgroundColor(Color.BLACK)
        if (software) w.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                if (consoleMessage != null) CarLog.add("JS: ${consoleMessage.message()} (${consoleMessage.lineNumber()})")
                return true
            }
        }
        w.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                CarLog.add("Página iniciada")
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                CarLog.add("Página cargada")
                setStatus("Página cargada")
                if (url != null && url.contains("m.youtube.com/watch")) {
                    // Web de YouTube: el <video> ocupa toda la pantalla del carro y avisa si está en play o pausa.
                    view?.evaluateJavascript(WATCH_SCRIPT, null)
                }
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                CarLog.add("Error web ${error?.errorCode} ${error?.description} ${request?.url}")
            }

            override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                CarLog.add("El WebView se cerró")
                setStatus("El WebView se cerró")
                return true
            }

            // Solo se bloquea cambiar la página principal; el iframe de YouTube debe poder cargar.
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                if (request == null) return true
                val host = request.url.host.orEmpty()
                val allowed = host.endsWith("youtube.com") || host.endsWith("google.com")
                return request.isForMainFrame && !allowed
            }
        }
        w.addJavascriptInterface(bridge, "Android")
        web = w
        root.addView(w, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        // Mensaje nativo encima del WebView: si se ve texto pero no la página, el problema es el WebView.
        val tv = TextView(context)
        tv.textSize = 13f
        tv.setTextColor(Color.WHITE)
        tv.setBackgroundColor(0xAA000000.toInt())
        tv.setPadding(16, 8, 16, 8)
        tv.text = "Parkio: abriendo…"
        status = tv
        root.addView(
            tv,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.START,
            ),
        )

        setContentView(root)
        w.loadDataWithBaseURL(PlayerHtml.BASE_URL, html, "text/html", "utf-8", null)
    }

    override fun onStop() {
        web?.destroy()
        web = null
        super.onStop()
    }

    fun setStatus(text: String?) {
        val tv = status ?: return
        tv.post {
            if (text == null) {
                tv.visibility = View.GONE
            } else {
                tv.text = "Parkio: $text"
                tv.visibility = View.VISIBLE
            }
        }
    }

    fun evalJs(js: String) {
        val w = web ?: return
        w.post { w.evaluateJavascript(js, null) }
    }

    /** Carga la página de YouTube del video (plan B cuando el reproductor incrustado falla). */
    fun loadWatch(videoId: String) {
        val w = web ?: return
        val id = videoId.filter { it.isLetterOrDigit() || it == '_' || it == '-' }
        w.post { w.loadUrl("https://m.youtube.com/watch?v=$id") }
    }

    private companion object {
        const val WATCH_SCRIPT =
            "(function(){var n=0;var t=setInterval(function(){var v=document.querySelector('video');" +
                "if(!v){if(++n>80){clearInterval(t);}return;}clearInterval(t);" +
                "v.style.cssText='position:fixed;left:0;top:0;width:100vw;height:100vh;z-index:2147483647;background:#000;object-fit:contain';" +
                "v.addEventListener('play',function(){Android.playing(true);});" +
                "v.addEventListener('pause',function(){Android.playing(false);});" +
                "try{var pl=document.querySelector('.html5-video-player');if(pl&&pl.unMute){pl.unMute();}}catch(e){}" +
                "v.muted=false;v.volume=1;v.play();},500);})();"
    }
}
