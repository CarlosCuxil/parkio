package app.parkio.car

import androidx.car.app.AppManager
import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.CarColor
import androidx.car.app.model.CarIcon
import androidx.car.app.model.OnClickListener
import androidx.car.app.model.Template
import androidx.car.app.navigation.model.NavigationTemplate
import androidx.core.graphics.drawable.IconCompat
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import app.parkio.R
import app.parkio.data.Video
import org.json.JSONObject

/**
 * Pantalla que usa la superficie del carro. Se declara con NavigationTemplate: es la plantilla
 * que le pide a Android Auto una superficie para dibujar. La página se dibuja ahí y los botones
 * de la barra de acciones (que se alcanzan con la perilla) la controlan.
 */
abstract class SurfaceScreen(
    ctx: CarContext,
    private val asset: String,
    arg: String,
) : Screen(ctx) {

    protected val renderer = SurfaceRenderer(ctx, asset, arg)

    init {
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onCreate(owner: LifecycleOwner) {
                CarLog.add("Pantalla $asset creada")
                carContext.getCarService(AppManager::class.java).setSurfaceCallback(renderer)
            }

            override fun onDestroy(owner: LifecycleOwner) {
                try {
                    carContext.getCarService(AppManager::class.java).setSurfaceCallback(null)
                } catch (e: Exception) {
                }
                renderer.release()
                CarLog.add("Pantalla $asset cerrada")
            }
        })
    }

    protected fun exitAction(): Action =
        Action.Builder().setTitle("Salir").setOnClickListener { screenManager.pop() }.build()

    protected fun iconAction(res: Int, onClick: () -> Unit): Action =
        Action.Builder()
            .setIcon(
                CarIcon.Builder(IconCompat.createWithResource(carContext, res))
                    .setTint(CarColor.DEFAULT)
                    .build()
            )
            .setOnClickListener(OnClickListener { onClick() })
            .build()
}

/** Reproduce un video de YouTube con el reproductor oficial incrustado. Solo con el carro estacionado. */
class PlayerScreen(
    ctx: CarContext,
    private val hub: CarHub,
    video: Video,
) : SurfaceScreen(ctx, "car/player.html", video.id) {

    private var playing = true

    // Seguridad: si el carro se mueve, el video se pausa y se cierra.
    private val onHub: () -> Unit = {
        if (!hub.parked) {
            renderer.eval("window.parkio&&parkio.pause()")
            screenManager.pop()
        }
    }

    init {
        renderer.onPlaying = { p ->
            playing = p
            invalidate()
        }
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onCreate(owner: LifecycleOwner) {
                hub.addListener(onHub)
            }

            override fun onDestroy(owner: LifecycleOwner) {
                hub.removeListener(onHub)
            }
        })
    }

    override fun onGetTemplate(): Template {
        val controls = ActionStrip.Builder()
            .addAction(iconAction(R.drawable.ic_rew) { renderer.eval("parkio.seek(-10)") })
            .addAction(
                iconAction(if (playing) R.drawable.ic_pause else R.drawable.ic_play) {
                    renderer.eval(if (playing) "parkio.pause()" else "parkio.play()")
                    playing = !playing
                    invalidate()
                }
            )
            .addAction(iconAction(R.drawable.ic_fwd) { renderer.eval("parkio.seek(30)") })
            .build()
        return NavigationTemplate.Builder()
            .setActionStrip(ActionStrip.Builder().addAction(exitAction()).build())
            .setMapActionStrip(controls)
            .build()
    }
}

/** Barras animadas con FPS para ver si la pantalla del carro aguanta movimiento fluido. */
class TestScreen(ctx: CarContext) : SurfaceScreen(ctx, "car/test.html", "") {

    override fun onGetTemplate(): Template =
        NavigationTemplate.Builder()
            .setActionStrip(ActionStrip.Builder().addAction(exitAction()).build())
            .build()
}
