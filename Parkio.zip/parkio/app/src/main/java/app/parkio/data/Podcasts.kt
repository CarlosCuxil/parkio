package app.parkio.data

import android.content.Context
import android.util.Xml
import app.parkio.ParkioApp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Podcast(val title: String, val feedUrl: String, val art: String)

data class Episode(
    val audioUrl: String,
    val title: String,
    val podcast: String,
    val art: String,
    val duration: String,
)

/**
 * Podcasts por RSS (audio abierto, sin YouTube). Búsqueda con el directorio público de iTunes.
 * También guarda suscripciones, historial y la posición de cada episodio para reanudar.
 */
object PodcastRepo {
    private const val PREFS = "parkio_podcasts"
    private val prefs get() = ParkioApp.instance.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ---------- Red ----------

    private fun httpGet(url: String): String {
        var current = url
        repeat(6) {
            val conn = URL(current).openConnection() as HttpURLConnection
            try {
                conn.connectTimeout = 10_000
                conn.readTimeout = 20_000
                conn.instanceFollowRedirects = false
                conn.setRequestProperty("User-Agent", "Parkio/0.1")
                val code = conn.responseCode
                if (code in 300..399) {
                    val loc = conn.getHeaderField("Location") ?: error("Redirección sin destino")
                    current = URL(URL(current), loc).toString()
                } else if (code in 200..299) {
                    return conn.inputStream.bufferedReader().use { it.readText() }
                } else {
                    error("Error $code al leer el podcast")
                }
            } finally {
                conn.disconnect()
            }
        }
        error("Demasiadas redirecciones")
    }

    suspend fun search(term: String): List<Podcast> = withContext(Dispatchers.IO) {
        val url = "https://itunes.apple.com/search?media=podcast&limit=20&term=" + URLEncoder.encode(term, "UTF-8")
        val arr = JSONObject(httpGet(url)).optJSONArray("results") ?: return@withContext emptyList()
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val feed = o.optString("feedUrl")
            if (feed.isEmpty()) null
            else Podcast(
                title = o.optString("collectionName"),
                feedUrl = feed,
                art = o.optString("artworkUrl600").ifEmpty { o.optString("artworkUrl100") },
            )
        }
    }

    suspend fun episodes(p: Podcast): List<Episode> = withContext(Dispatchers.IO) {
        parseFeed(httpGet(p.feedUrl), p)
    }

    private fun parseFeed(xml: String, p: Podcast): List<Episode> {
        val out = ArrayList<Episode>()
        try {
            val parser = Xml.newPullParser()
            parser.setInput(StringReader(xml))
            var event = parser.eventType
            var inItem = false
            var title = ""
            var audio = ""
            var dur = ""
            var itemArt = ""
            var chanArt = ""
            while (event != XmlPullParser.END_DOCUMENT && out.size < 40) {
                if (event == XmlPullParser.START_TAG) {
                    when (parser.name) {
                        "item" -> {
                            inItem = true; title = ""; audio = ""; dur = ""; itemArt = ""
                        }
                        "title" -> if (inItem) title = parser.nextText().trim()
                        "enclosure" -> if (inItem) audio = parser.getAttributeValue(null, "url").orEmpty()
                        "itunes:duration" -> if (inItem) dur = parser.nextText().trim()
                        "itunes:image" -> {
                            val href = parser.getAttributeValue(null, "href").orEmpty()
                            if (inItem) itemArt = href else if (chanArt.isEmpty()) chanArt = href
                        }
                    }
                } else if (event == XmlPullParser.END_TAG && parser.name == "item") {
                    inItem = false
                    if (audio.isNotEmpty()) {
                        out += Episode(
                            audioUrl = audio,
                            title = title.ifEmpty { "Episodio" },
                            podcast = p.title,
                            art = itemArt.ifEmpty { chanArt.ifEmpty { p.art } },
                            duration = prettyDuration(dur),
                        )
                    }
                }
                event = parser.next()
            }
        } catch (e: Exception) {
            // devolvemos lo que se alcanzó a leer
        }
        return out
    }

    private fun prettyDuration(raw: String): String {
        if (raw.isEmpty()) return ""
        if (raw.contains(':')) return raw
        val s = raw.toLongOrNull() ?: return ""
        val h = s / 3600
        val m = (s % 3600) / 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s % 60) else "%d:%02d".format(m, s % 60)
    }

    // ---------- Suscripciones ----------

    fun subs(): List<Podcast> {
        val arr = try { JSONArray(prefs.getString("subs", "[]")) } catch (e: Exception) { JSONArray() }
        return (0 until arr.length()).mapNotNull {
            val o = arr.optJSONObject(it) ?: return@mapNotNull null
            Podcast(o.optString("title"), o.optString("feed"), o.optString("art"))
        }
    }

    private fun saveSubs(list: List<Podcast>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("title", it.title).put("feed", it.feedUrl).put("art", it.art)) }
        prefs.edit().putString("subs", arr.toString()).apply()
    }

    fun isSubscribed(p: Podcast) = subs().any { it.feedUrl == p.feedUrl }

    fun subscribe(p: Podcast) {
        if (!isSubscribed(p)) saveSubs(subs() + p)
    }

    fun unsubscribe(p: Podcast) = saveSubs(subs().filter { it.feedUrl != p.feedUrl })

    // ---------- Posición e historial ----------

    fun position(audioUrl: String): Long = prefs.getLong("pos:$audioUrl", 0L)
    fun savePosition(audioUrl: String, ms: Long) = prefs.edit().putLong("pos:$audioUrl", ms).apply()
    fun clearPosition(audioUrl: String) = prefs.edit().remove("pos:$audioUrl").apply()

    fun history(): List<Episode> {
        val arr = try { JSONArray(prefs.getString("history", "[]")) } catch (e: Exception) { JSONArray() }
        return (0 until arr.length()).mapNotNull {
            val o = arr.optJSONObject(it) ?: return@mapNotNull null
            Episode(o.optString("url"), o.optString("title"), o.optString("podcast"), o.optString("art"), o.optString("dur"))
        }
    }

    fun addHistory(ep: Episode) {
        val list = (listOf(ep) + history().filter { it.audioUrl != ep.audioUrl }).take(10)
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("url", it.audioUrl).put("title", it.title)
                    .put("podcast", it.podcast).put("art", it.art).put("dur", it.duration)
            )
        }
        prefs.edit().putString("history", arr.toString()).apply()
    }
}
