package app.parkio.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.parkio.data.Load
import app.parkio.data.Video
import coil.compose.AsyncImage

/**
 * Marca de Parkio: una "P" hecha con un botón de play (el semicírculo de la P es el triángulo) sobre grafito,
 * con un punto tenue que hace de testigo de "estacionado".
 */
@Composable
fun Logo(size: Dp) {
    Canvas(Modifier.size(size)) {
        val s = this.size.width
        drawRoundRect(Color(0xFF0F1318), cornerRadius = CornerRadius(s * 0.26f))
        drawRoundRect(
            Pk.Accent.copy(alpha = 0.35f),
            cornerRadius = CornerRadius(s * 0.26f),
            style = Stroke(width = s * 0.02f),
        )
        // Tronco de la P
        drawRoundRect(
            Pk.Accent,
            topLeft = Offset(s * 0.315f, s * 0.215f),
            size = Size(s * 0.105f, s * 0.57f),
            cornerRadius = CornerRadius(s * 0.05f),
        )
        // Panza de la P = triángulo de play, con las puntas redondeadas
        val p = Path().apply {
            moveTo(s * 0.47f, s * 0.26f)
            lineTo(s * 0.47f, s * 0.60f)
            lineTo(s * 0.74f, s * 0.43f)
            close()
        }
        drawPath(p, Pk.Accent)
        drawPath(p, Pk.Accent, style = Stroke(width = s * 0.05f, join = StrokeJoin.Round))
        // Testigo
        drawCircle(Pk.Accent.copy(alpha = 0.55f), radius = s * 0.04f, center = Offset(s * 0.68f, s * 0.72f))
    }
}

@Composable
fun TopBar(trailing: @Composable () -> Unit = {}) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(56.dp)
            .padding(start = 16.dp, end = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Logo(30.dp)
        Spacer(Modifier.width(10.dp))
        Text("Parkio", color = Pk.Text, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.weight(1f))
        trailing()
    }
}

@Composable
fun Chips(options: List<String>, selected: String, onSelect: (String) -> Unit) {
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(horizontal = 16.dp),
        modifier = Modifier.padding(bottom = 14.dp),
    ) {
        items(options) { c ->
            val on = c == selected
            Box(
                Modifier
                    .height(36.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(if (on) Pk.Accent else Pk.Surface2)
                    .clickable { onSelect(c) }
                    .padding(horizontal = 14.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    c,
                    color = if (on) Pk.OnAccent else Pk.TextSoft,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                )
            }
        }
    }
}

@Composable
fun VideoCard(v: Video, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(bottom = 22.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .background(Pk.Surface2)
        ) {
            AsyncImage(
                model = v.thumb,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
            if (v.duration.isNotEmpty()) {
                Text(
                    v.duration,
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(10.dp)
                        .background(Color(0xC7000000), RoundedCornerShape(6.dp))
                        .padding(horizontal = 7.dp, vertical = 3.dp),
                )
            }
        }
        Row(
            Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Box(
                Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Pk.Chan),
                contentAlignment = Alignment.Center,
            ) {
                Text(v.channel.take(1).uppercase(), color = Pk.Text, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
            }
            Column {
                Text(
                    v.title,
                    color = Pk.Text,
                    fontSize = 15.sp,
                    lineHeight = 20.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    listOf(v.channel, v.published).filter { it.isNotEmpty() }.joinToString(" · "),
                    color = Pk.Sub,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
        }
    }
}

@Composable
fun CompactRow(v: Video, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 16.dp, end = 16.dp, bottom = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            Modifier
                .size(width = 168.dp, height = 94.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Pk.Surface2)
        ) {
            AsyncImage(
                model = v.thumb,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
            if (v.duration.isNotEmpty()) {
                Text(
                    v.duration,
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(6.dp)
                        .background(Color(0xC7000000), RoundedCornerShape(5.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                )
            }
        }
        Column(Modifier.weight(1f)) {
            Text(
                v.title,
                color = Pk.Text,
                fontSize = 14.sp,
                lineHeight = 19.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                listOf(v.channel, v.published).filter { it.isNotEmpty() }.joinToString(" · "),
                color = Pk.Sub,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
    }
}

@Composable
fun ErrorBox(message: String, onRetry: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(message, color = Pk.Sub, fontSize = 14.sp)
        Box(
            Modifier
                .height(40.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(Pk.Accent)
                .clickable(onClick = onRetry)
                .padding(horizontal = 20.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text("Reintentar", color = Pk.OnAccent, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
        }
    }
}

fun LazyListScope.videoItems(load: Load<List<Video>>, onOpen: (Video) -> Unit, onRetry: () -> Unit) {
    when (load) {
        Load.Idle, Load.Loading -> item {
            Box(Modifier.fillMaxWidth().padding(48.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Pk.Accent)
            }
        }
        is Load.Err -> item { ErrorBox(load.message, onRetry) }
        is Load.Ok -> {
            if (load.value.isEmpty()) {
                item {
                    Text(
                        "No hay videos para mostrar.",
                        color = Pk.Sub,
                        modifier = Modifier.padding(24.dp),
                    )
                }
            } else {
                items(load.value) { v -> VideoCard(v) { onOpen(v) } }
            }
        }
    }
}
