package app.parkio.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.parkio.ParkioApp
import app.parkio.data.Auth
import app.parkio.data.Load
import app.parkio.data.Video
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val parkio = app as ParkioApp
    private val api get() = parkio.api

    val signedIn = MutableStateFlow(Auth.isSignedIn(app))
    val feed = MutableStateFlow<Load<List<Video>>>(Load.Idle)
    val results = MutableStateFlow<Load<List<Video>>>(Load.Idle)
    val subs = MutableStateFlow<Load<List<Video>>>(Load.Idle)
    val liked = MutableStateFlow<Load<List<Video>>>(Load.Idle)
    val current = MutableStateFlow<Video?>(null)
    val queue = parkio.carQueue
    val message = MutableSharedFlow<String>(extraBufferCapacity = 4)

    private fun launchLoad(target: MutableStateFlow<Load<List<Video>>>, block: suspend () -> List<Video>) {
        target.value = Load.Loading
        viewModelScope.launch {
            target.value = try {
                Load.Ok(block())
            } catch (e: Exception) {
                Load.Err(e.message ?: "Error de red")
            }
        }
    }

    fun loadFeed(chip: String) = launchLoad(feed) {
        if (chip == "Todo") api.popular() else api.search(chipQuery(chip))
    }

    fun search(q: String) {
        if (q.isNotBlank()) launchLoad(results) { api.search(q.trim()) }
    }

    fun loadSubs() = launchLoad(subs) { api.subscriptionsFeed() }
    fun loadLiked() = launchLoad(liked) { api.liked() }

    fun open(v: Video) {
        current.value = v
    }

    fun close() {
        current.value = null
    }

    fun sendToCar(v: Video) {
        parkio.carQueue.update { list -> (listOf(v) + list.filter { it.id != v.id }).take(30) }
        message.tryEmit("Enviado a la cola del carro")
    }

    fun like(v: Video) {
        viewModelScope.launch {
            message.emit(
                try {
                    api.like(v.id)
                    "Te gusta este video"
                } catch (e: Exception) {
                    e.message ?: "No se pudo dar me gusta"
                }
            )
        }
    }

    fun subscribe(v: Video) {
        viewModelScope.launch {
            message.emit(
                try {
                    api.subscribe(v.channelId)
                    "Suscrito a ${v.channel}"
                } catch (e: Exception) {
                    e.message ?: "No se pudo suscribir"
                }
            )
        }
    }

    fun onSignedIn() {
        signedIn.value = true
        loadSubs()
        loadLiked()
    }

    fun signOut() {
        Auth.signOut(getApplication())
        signedIn.value = false
        subs.value = Load.Idle
        liked.value = Load.Idle
    }

    private fun chipQuery(chip: String) = when (chip) {
        "Música" -> "música"
        "Autos" -> "autos carros"
        "Tecnología" -> "tecnología"
        "En vivo" -> "en vivo"
        "Podcasts" -> "podcast"
        else -> chip
    }
}
