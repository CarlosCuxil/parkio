package app.parkio.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Forward30
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.parkio.data.Episode
import app.parkio.data.Load
import app.parkio.data.Podcast
import app.parkio.data.PodcastRepo
import app.parkio.media.PodcastPlayer
import coil.compose.AsyncImage
import kotlinx.coroutines.launch

@Composable
fun PodcastsScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { PodcastPlayer.connect(ctx) }

    var subs by remember { mutableStateOf(PodcastRepo.subs()) }
    var query by rememberSaveable { mutableStateOf("") }
    var results by remember { mutableStateOf<Load<List<Podcast>>>(Load.Idle) }
    var selected by remember { mutableStateOf<Podcast?>(null) }
    var episodes by remember { mutableStateOf<Load<List<Episode>>>(Load.Idle) }

    fun openPodcast(p: Podcast) {
        selected = p
        episodes = Load.Loading
        scope.launch {
            episodes = try {
                Load.Ok(PodcastRepo.episodes(p))
            } catch (e: Exception) {
                Load.Err(e.message ?: "No se pudo leer el podcast")
            }
        }
    }

    fun runSearch() {
        if (query.isBlank()) return
        results = Load.Loading
        scope.launch {
            results = try {
                Load.Ok(PodcastRepo.search(query.trim()))
            } catch (e: Exception) {
                Load.Err(e.message ?: "No se pudo buscar")
            }
        }
    }

    fun toggleSub(p: Podcast) {
        if (PodcastRepo.isSubscribed(p)) PodcastRepo.unsubscribe(p) else PodcastRepo.subscribe(p)
        subs = PodcastRepo.subs()
    }

    val current = selected
    BackHandler(enabled = current != null) { selected = null }

    if (current != null) {
        val subscribed = subs.any { it.feedUrl == current.feedUrl }
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    TextButton(onClick = { selected = null }) { Text("‹ Volver", color = Pk.Sub) }
                }
            }
            item {
                PodcastRow(current, subscribed, onClick = {}, onToggle = { toggleSub(current) })
            }
            when (val e = episodes) {
                Load.Idle, Load.Loading -> item {
                    Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = Pk.Accent)
                    }
                }
                is Load.Err -> item { ErrorBox(e.message) { openPodcast(current) } }
                is Load.Ok -> items(e.value) { ep -> EpisodeRow(ep) { PodcastPlayer.play(ctx, ep) } }
            }
        }
        return
    }

    LazyColumn(Modifier.fillMaxSize()) {
        item { TopBar() }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                placeholder = { Text("Buscar podcasts", color = Pk.Sub) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = Pk.Sub) },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { runSearch() }),
                shape = RoundedCornerShape(28.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Pk.Accent,
                    unfocusedBorderColor = Pk.Line,
                    focusedContainerColor = Pk.Surface,
                    unfocusedContainerColor = Pk.Surface,
                    cursorColor = Pk.Accent,
                    focusedTextColor = Pk.Text,
                    unfocusedTextColor = Pk.Text,
                ),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            )
        }

        when (val r = results) {
            Load.Idle -> Unit
            Load.Loading -> item {
                Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Pk.Accent)
                }
            }
            is Load.Err -> item { ErrorBox(r.message) { runSearch() } }
            is Load.Ok -> {
                item { SectionLabel("Resultados") }
                items(r.value) { p ->
                    PodcastRow(p, subs.any { it.feedUrl == p.feedUrl }, onClick = { openPodcast(p) }, onToggle = { toggleSub(p) })
                }
            }
        }

        item { SectionLabel("Mis podcasts") }
        if (subs.isEmpty()) {
            item {
                Text(
                    "Busca un podcast y toca Suscribirme. Los episodios aparecen en la pantalla del carro.",
                    color = Pk.Sub, fontSize = 14.sp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                )
            }
        } else {
            items(subs) { p -> PodcastRow(p, true, onClick = { openPodcast(p) }, onToggle = { toggleSub(p) }) }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text, color = Pk.Text, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 8.dp),
    )
}

@Composable
private fun PodcastRow(p: Podcast, subscribed: Boolean, onClick: () -> Unit, onToggle: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        AsyncImage(
            model = p.art,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(56.dp).clip(RoundedCornerShape(10.dp)).background(Pk.Surface2),
        )
        Text(
            p.title, color = Pk.Text, fontSize = 15.sp, fontWeight = FontWeight.Bold,
            maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
        )
        Box(
            Modifier
                .height(36.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(if (subscribed) Pk.Surface2 else Pk.Accent)
                .clickable(onClick = onToggle)
                .padding(horizontal = 14.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                if (subscribed) "Quitar" else "Suscribirme",
                color = if (subscribed) Pk.TextSoft else Pk.OnAccent,
                fontSize = 13.sp, fontWeight = FontWeight.ExtraBold,
            )
        }
    }
}

@Composable
private fun EpisodeRow(ep: Episode, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Icon(Icons.Filled.PlayArrow, contentDescription = "Reproducir", tint = Pk.Accent)
        Column(Modifier.weight(1f)) {
            Text(
                ep.title, color = Pk.Text, fontSize = 14.sp, lineHeight = 19.sp, fontWeight = FontWeight.Bold,
                maxLines = 3, overflow = TextOverflow.Ellipsis,
            )
            if (ep.duration.isNotEmpty()) {
                Text(ep.duration, color = Pk.Sub, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
            }
        }
    }
}

/** Barra de reproducción de podcast, sobre la navegación. Solo aparece si hay algo cargado. */
@Composable
fun PodcastMiniBar() {
    val ctx = LocalContext.current
    val active by PodcastPlayer.active.collectAsStateWithLifecycle()
    if (!active) return
    val title by PodcastPlayer.title.collectAsStateWithLifecycle()
    val artist by PodcastPlayer.artist.collectAsStateWithLifecycle()
    val playing by PodcastPlayer.playing.collectAsStateWithLifecycle()

    Row(
        Modifier
            .fillMaxWidth()
            .background(Pk.Surface)
            .padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Pk.Text, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(artist, color = Pk.Sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconButton(onClick = { PodcastPlayer.back(ctx) }) {
            Icon(Icons.Filled.Replay10, contentDescription = "Atrasar 10 segundos", tint = Pk.Text)
        }
        IconButton(onClick = { PodcastPlayer.toggle(ctx) }) {
            Icon(
                if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                contentDescription = if (playing) "Pausar" else "Reproducir",
                tint = Pk.Accent,
                modifier = Modifier.size(32.dp),
            )
        }
        IconButton(onClick = { PodcastPlayer.forward(ctx) }) {
            Icon(Icons.Filled.Forward30, contentDescription = "Adelantar 30 segundos", tint = Pk.Text)
        }
    }
}
