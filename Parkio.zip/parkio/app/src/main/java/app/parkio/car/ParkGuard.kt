package app.parkio.car

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock

/**
 * Decide si el carro está estacionado. El video SOLO se permite cuando esta guardia dice que sí.
 *
 * Reglas (a prueba de fallos: ante la duda, bloqueado):
 *  - Estacionado = fix de GPS reciente (< 8 s) con velocidad < 1 m/s sostenida durante 3 s.
 *  - Sin fix de GPS (garaje, sin permiso de ubicación) no se puede saber: se ofrece un botón manual
 *    de "Estoy estacionado", pero solo si en el último minuto no hubo movimiento, dura 10 minutos y
 *    se anula apenas el GPS detecte que el carro se mueve.
 *  - Si el GPS se pierde y el carro venía en movimiento, NO se ofrece el botón manual.
 */
class ParkGuard(
    private val context: Context,
    private val onChange: (parked: Boolean, canConfirm: Boolean) -> Unit,
) : LocationListener {

    private val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private val handler = Handler(Looper.getMainLooper())

    private var started = false
    private var lastFixAt = 0L
    private var stillSince = 0L
    private var lastMovingAt = 0L
    private var manualUntil = 0L
    private var lastParked: Boolean? = null
    private var lastCan: Boolean? = null

    private val tick = object : Runnable {
        override fun run() {
            evaluate()
            handler.postDelayed(this, 1000)
        }
    }

    @SuppressLint("MissingPermission")
    fun start() {
        if (started) return
        started = true
        lastParked = null
        lastCan = null
        if (context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            try {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this, Looper.getMainLooper())
            } catch (e: Exception) {
                // sin GPS disponible: queda bloqueado salvo confirmación manual
            }
        }
        handler.post(tick)
    }

    fun stop() {
        started = false
        handler.removeCallbacks(tick)
        try {
            lm.removeUpdates(this)
        } catch (e: Exception) {
        }
    }

    fun confirmManual() {
        val now = SystemClock.elapsedRealtime()
        if (canConfirm(now)) {
            manualUntil = now + 10 * 60 * 1000L
            evaluate()
        }
    }

    private fun fresh(now: Long) = lastFixAt != 0L && now - lastFixAt < 8000
    private fun canConfirm(now: Long) = !fresh(now) && (lastMovingAt == 0L || now - lastMovingAt > 60_000)

    private fun evaluate() {
        val now = SystemClock.elapsedRealtime()
        val byGps = fresh(now) && stillSince != 0L && now - stillSince >= 3000
        val manual = !fresh(now) && now < manualUntil
        val parked = byGps || manual
        val can = !parked && canConfirm(now)
        if (parked != lastParked || can != lastCan) {
            lastParked = parked
            lastCan = can
            onChange(parked, can)
        }
    }

    override fun onLocationChanged(location: Location) {
        val now = SystemClock.elapsedRealtime()
        lastFixAt = now
        val speed = if (location.hasSpeed()) location.speed else Float.MAX_VALUE
        if (speed >= 1.0f) {
            lastMovingAt = now
            stillSince = 0L
            manualUntil = 0L
        } else if (stillSince == 0L) {
            stillSince = now
        }
        evaluate()
    }

    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}

    @Deprecated("Requerido en Android < 11")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
}
