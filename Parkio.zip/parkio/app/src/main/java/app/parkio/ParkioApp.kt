package app.parkio

import android.app.Application
import app.parkio.data.Auth
import app.parkio.data.Video
import app.parkio.data.YouTubeApi
import kotlinx.coroutines.flow.MutableStateFlow

class ParkioApp : Application() {

    /** Un solo cliente de API para la app del teléfono y para la pantalla del carro (mismo proceso). */
    val api: YouTubeApi by lazy {
        YouTubeApi(tokenProvider = { Auth.silentToken(this) }, apiKey = BuildConfig.YT_API_KEY)
    }

    /** Videos que enviaste desde el teléfono con "Enviar al carro". */
    val carQueue = MutableStateFlow<List<Video>>(emptyList())

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    companion object {
        lateinit var instance: ParkioApp
            private set
    }
}
