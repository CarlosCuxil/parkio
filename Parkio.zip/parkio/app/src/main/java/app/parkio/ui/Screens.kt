package app.parkio.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.car.app.connection.CarConnection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.parkio.data.Load

private val CHIPS = listOf("Todo", "Música", "Autos", "Tecnología", "En vivo", "Podcasts")

@Composable
fun CarStatusCard() {
    val ctx = LocalContext.current
    val connection = remember { CarConnection(ctx) }
    val type by connection.type.observeAsState(CarConnection.CONNECTION_TYPE_NOT_CONNECTED)
    val connected = type == CarConnection.CONNECTION_TYPE_PROJECTION
    Row(
        Modifier
            .padding(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 12.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Pk.Surface)
            .border(1.dp, Pk.Line, RoundedCornerShape(14.dp))
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(Pk.Bg),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Filled.DirectionsCar, contentDescription = null, tint = if (connected) Pk.Accent else Pk.Sub)
        }
        Column(Modifier.weight(1f)) {
            Text(
                if (connected) "Android Auto conectado" else "Android Auto desconectado",
                color = Pk.Text, fontSize = 14.sp, fontWeight = FontWeight.Bold,
            )
            Text(
                if (connected) "El video se activa solo al estacionar" else "Conecta el cable del carro para usar su pantalla",
                color = Pk.Sub, fontSize = 12.sp,
            )
        }
        if (connected) Text("Listo", color = Pk.Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun HomeScreen(vm: AppViewModel) {
    val feed by vm.feed.collectAsStateWithLifecycle()
    var chip by rememberSaveable { mutableStateOf("Todo") }
    LaunchedEffect(chip) { vm.loadFeed(chip) }

    LazyColumn(Modifier.fillMaxSize()) {
        item {
            TopBar {
                Box(
                    Modifier.padding(end = 8.dp).size(32.dp).clip(CircleShape).background(Pk.Chan),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.Person, contentDescription = "Tu cuenta", tint = Pk.Text, modifier = Modifier.size(20.dp)) }
            }
        }
        item { CarStatusCard() }
        item { Chips(CHIPS, chip) { chip = it } }
        videoItems(feed, vm::open) { vm.loadFeed(chip) }
    }
}

@Composable
fun ExploreScreen(vm: AppViewModel) {
    val results by vm.results.collectAsStateWithLifecycle()
    var query by rememberSaveable { mutableStateOf("") }

    LazyColumn(Modifier.fillMaxSize()) {
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                placeholder = { Text("Buscar videos", color = Pk.Sub) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = Pk.Sub) },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { vm.search(query) }),
                shape = RoundedCornerShape(28.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Pk.Accent,
                    unfocusedBorderColor = Pk.Line,
                    focusedContainerColor = Pk.Surface,
                    unfocusedContainerColor = Pk.Surface,
                    cursorColor = Pk.Accent,
                    focusedTextColor = Pk.Text,
                    unfocusedTextColor = Pk.Text,
                ),
                modifier = Modifier.fillMaxWidth().padding(16.dp),
            )
        }
        if (results is Load.Idle) {
            item {
                Text(
                    "Busca algo para empezar.",
                    color = Pk.Sub,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
                )
            }
        } else {
            videoItems(results, vm::open) { vm.search(query) }
        }
    }
}

@Composable
fun SubsScreen(vm: AppViewModel, onSignIn: () -> Unit) {
    val signedIn by vm.signedIn.collectAsStateWithLifecycle()
    val subs by vm.subs.collectAsStateWithLifecycle()
    if (!signedIn) {
        LoginPrompt(onSignIn)
        return
    }
    LaunchedEffect(Unit) { if (subs is Load.Idle) vm.loadSubs() }
    LazyColumn(Modifier.fillMaxSize()) {
        item { TopBar() }
        videoItems(subs, vm::open) { vm.loadSubs() }
    }
}

@Composable
fun LibraryScreen(vm: AppViewModel, onSignIn: () -> Unit) {
    val signedIn by vm.signedIn.collectAsStateWithLifecycle()
    val liked by vm.liked.collectAsStateWithLifecycle()
    val queue by vm.queue.collectAsStateWithLifecycle()
    LaunchedEffect(signedIn) { if (signedIn && liked is Load.Idle) vm.loadLiked() }

    LazyColumn(Modifier.fillMaxSize()) {
        item { TopBar() }
        item { SectionTitle("Cola del carro") }
        if (queue.isEmpty()) {
            item {
                Text(
                    "Vacía. Abre un video y toca «Enviar al carro».",
                    color = Pk.Sub, fontSize = 14.sp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                )
            }
        } else {
            items(queue) { v -> CompactRow(v) { vm.open(v) } }
        }
        item { Spacer(Modifier.height(12.dp)) }
        if (!signedIn) {
            item { LoginPrompt(onSignIn, compact = true) }
        } else {
            item { SectionTitle("Videos que te gustan") }
            videoItems(liked, vm::open) { vm.loadLiked() }
            item { TextButton(onClick = { vm.signOut() }, modifier = Modifier.padding(8.dp)) { Text("Cerrar sesión", color = Pk.Sub) } }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        color = Pk.Text, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 10.dp),
    )
}

@Composable
fun LoginPrompt(onSignIn: () -> Unit, compact: Boolean = false) {
    Column(
        Modifier
            .then(if (compact) Modifier else Modifier.fillMaxSize())
            .padding(horizontal = 24.dp, vertical = if (compact) 8.dp else 56.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        if (!compact) Logo(64.dp)
        Text(
            if (compact) "Inicia sesión para ver tus Me gusta" else "Tus videos,\ntambién en el carro.",
            color = Pk.Text,
            fontSize = if (compact) 18.sp else 32.sp,
            lineHeight = if (compact) 24.sp else 37.sp,
            fontWeight = FontWeight.ExtraBold,
        )
        Text(
            "Entra con tu cuenta de Google para ver tus suscripciones, tus videos que te gustan y suscribirte desde Parkio.",
            color = Pk.Sub, fontSize = 15.sp, lineHeight = 22.sp,
        )
        if (!compact) Spacer(Modifier.weight(1f))
        Box(
            Modifier
                .fillMaxWidth()
                .height(56.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(Pk.Text)
                .clickable(onClick = onSignIn),
            contentAlignment = Alignment.Center,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Person, contentDescription = null, tint = Pk.Bg)
                Spacer(Modifier.width(10.dp))
                Text("Continuar con Google", color = Pk.Bg, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
        Text(
            "El inicio de sesión lo hace Google directamente. Parkio nunca ve ni guarda tu contraseña.",
            color = Pk.Sub, fontSize = 12.sp, lineHeight = 18.sp,
        )
    }
}
