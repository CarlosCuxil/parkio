package app.parkio.media

import android.os.Handler
import android.os.Looper
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.LibraryResult
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaLibraryService.LibraryParams
import androidx.media3.session.MediaLibraryService.MediaLibrarySession
import androidx.media3.session.MediaSession
import app.parkio.data.Episode
import app.parkio.data.Podcast
import app.parkio.data.PodcastRepo
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.guava.future

/**
 * Reproductor de podcasts como app de MÚSICA/AUDIO de Android Auto: sigue sonando con la pantalla
 * apagada y el carro lo muestra con controles grandes. Árbol: raíz -> Continuar escuchando / cada
 * podcast suscrito -> episodios.
 */
@OptIn(UnstableApi::class)
class PlaybackService : MediaLibraryService() {

    private var session: MediaLibrarySession? = null
    private lateinit var player: ExoPlayer
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())

    private val saver = object : Runnable {
        override fun run() {
            saveProgress()
            if (player.isPlaying) handler.postDelayed(this, 5000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val http = DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true)
        player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(this).setDataSourceFactory(http))
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA)
                    .build(),
                true,
            )
            .setHandleAudioBecomingNoisy(true)
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(30_000)
            .build()
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                handler.removeCallbacks(saver)
                if (isPlaying) {
                    recordHistory()
                    handler.post(saver)
                } else {
                    saveProgress()
                }
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                recordHistory()
            }
        })
        session = MediaLibrarySession.Builder(this, player, LibraryCallback()).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaLibrarySession? = session

    override fun onDestroy() {
        handler.removeCallbacks(saver)
        saveProgress()
        session?.release()
        player.release()
        session = null
        scope.cancel()
        super.onDestroy()
    }

    private fun saveProgress() {
        val item = player.currentMediaItem ?: return
        val dur = player.duration
        val pos = player.currentPosition
        if (dur != C.TIME_UNSET && pos > dur - 30_000) PodcastRepo.clearPosition(item.mediaId)
        else PodcastRepo.savePosition(item.mediaId, pos)
    }

    private fun recordHistory() {
        val item = player.currentMediaItem ?: return
        if (item.mediaMetadata.title != null) PodcastRepo.addHistory(item.toEpisode())
    }

    private var lastSearch: Pair<String, List<Podcast>>? = null

    /** Busca podcasts en el directorio de iTunes. Guarda la última búsqueda para no repetirla. */
    private suspend fun searchPodcasts(query: String): List<Podcast> {
        val q = query.trim()
        lastSearch?.let { if (it.first == q) return it.second }
        val found = if (q.isEmpty()) emptyList() else PodcastRepo.search(q)
        lastSearch = q to found
        return found
    }

    private fun resolve(items: List<MediaItem>): List<MediaItem> =
        // Android Auto manda solo el mediaId: en los episodios, el mediaId ES la URL del audio.
        items.map { it.buildUpon().setUri(it.mediaId).build() }

    private inner class LibraryCallback : MediaLibrarySession.Callback {

        override fun onGetLibraryRoot(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            params: LibraryParams?,
        ): ListenableFuture<LibraryResult<MediaItem>> =
            Futures.immediateFuture(LibraryResult.ofItem(folderItem(ROOT, "Parkio podcasts"), params))

        override fun onGetChildren(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            parentId: String,
            page: Int,
            pageSize: Int,
            params: LibraryParams?,
        ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> = scope.future {
            try {
                val items: List<MediaItem> = when {
                    parentId == ROOT -> buildList {
                        if (PodcastRepo.history().isNotEmpty()) add(folderItem(RESUME, "Continuar escuchando"))
                        val subs = PodcastRepo.subs()
                        subs.forEach { add(folderItem(POD + it.feedUrl, it.title, it.art)) }
                        if (subs.isEmpty()) add(folderItem(HINT_PODCASTS, "Sin podcasts: suscríbete en la app del cel"))
                        add(folderItem(HINT_VIDEO, "Para ver video: abre «Parkio Video» en el lanzador"))
                    }
                    parentId == RESUME -> PodcastRepo.history().map { it.toMediaItem() }
                    parentId.startsWith(POD) -> {
                        val feed = parentId.removePrefix(POD)
                        // Un podcast encontrado con la lupa todavía no está suscrito: se busca también en la última búsqueda.
                        // Antes devolvía lista vacía y por eso salía "No items".
                        val p = PodcastRepo.subs().firstOrNull { it.feedUrl == feed }
                            ?: lastSearch?.second?.firstOrNull { it.feedUrl == feed }
                            ?: Podcast("Podcast", feed, "")
                        PodcastRepo.episodes(p).map { it.toMediaItem() }
                    }
                    else -> emptyList()
                }
                val paged = items.drop(page * pageSize).take(pageSize)
                LibraryResult.ofItemList(ImmutableList.copyOf(paged), params)
            } catch (e: Exception) {
                LibraryResult.ofError<ImmutableList<MediaItem>>(LibraryResult.RESULT_ERROR_IO)
            }
        }

        override fun onGetItem(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            mediaId: String,
        ): ListenableFuture<LibraryResult<MediaItem>> {
            // Android Auto pide esto al suscribirse a una carpeta. Media3 EXIGE que la carpeta diga
            // isBrowsable=true; si devolvíamos un item pelado, la app se caía (causa raíz del carro negro).
            return try {
                val item: MediaItem? = when {
                    mediaId == ROOT -> folderItem(ROOT, "Parkio podcasts")
                    mediaId == RESUME -> folderItem(RESUME, "Continuar escuchando")
                    mediaId == HINT_PODCASTS -> folderItem(HINT_PODCASTS, "Sin podcasts: suscríbete en la app del cel")
                    mediaId == HINT_VIDEO -> folderItem(HINT_VIDEO, "Para ver video: abre «Parkio Video» en el lanzador")
                    mediaId.startsWith(POD) -> {
                        val feed = mediaId.removePrefix(POD)
                        val p = PodcastRepo.subs().firstOrNull { it.feedUrl == feed }
                        folderItem(mediaId, p?.title ?: "Podcast", p?.art ?: "")
                    }
                    else -> {
                        val known = PodcastRepo.history().firstOrNull { it.audioUrl == mediaId }
                        known?.toMediaItem() ?: Episode(
                            audioUrl = mediaId, title = "Episodio", podcast = "", art = "", duration = "",
                        ).toMediaItem()
                    }
                }
                val result: LibraryResult<MediaItem> =
                    if (item != null) LibraryResult.ofItem(item, null)
                    else LibraryResult.ofError<MediaItem>(LibraryResult.RESULT_ERROR_BAD_VALUE)
                Futures.immediateFuture(result)
            } catch (e: Exception) {
                Futures.immediateFuture(LibraryResult.ofError<MediaItem>(LibraryResult.RESULT_ERROR_UNKNOWN))
            }
        }

        // Búsqueda desde el carro (la lupa). Sin esto Android Auto se quedaba cargando para siempre.
        override fun onSearch(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            query: String,
            params: LibraryParams?,
        ): ListenableFuture<LibraryResult<Void>> = scope.future {
            try {
                val found = searchPodcasts(query)
                session.notifySearchResultChanged(browser, query, found.size, params)
                LibraryResult.ofVoid()
            } catch (e: Exception) {
                LibraryResult.ofError<Void>(LibraryResult.RESULT_ERROR_IO)
            }
        }

        override fun onGetSearchResult(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            query: String,
            page: Int,
            pageSize: Int,
            params: LibraryParams?,
        ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> = scope.future {
            try {
                val found = searchPodcasts(query).map { folderItem(POD + it.feedUrl, it.title, it.art) }
                val paged = found.drop(page * pageSize).take(pageSize)
                LibraryResult.ofItemList(ImmutableList.copyOf(paged), params)
            } catch (e: Exception) {
                LibraryResult.ofError<ImmutableList<MediaItem>>(LibraryResult.RESULT_ERROR_IO)
            }
        }

        override fun onAddMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>,
        ): ListenableFuture<MutableList<MediaItem>> =
            Futures.immediateFuture(resolve(mediaItems).toMutableList())

        override fun onSetMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>,
            startIndex: Int,
            startPositionMs: Long,
        ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> {
            val items = resolve(mediaItems)
            // Si no piden una posición concreta, se reanuda donde se quedó ese episodio.
            val pos = if (startPositionMs == C.TIME_UNSET && items.size == 1) {
                PodcastRepo.position(items[0].mediaId).takeIf { it > 0 } ?: C.TIME_UNSET
            } else startPositionMs
            return Futures.immediateFuture(
                MediaSession.MediaItemsWithStartPosition(items, if (startIndex < 0) 0 else startIndex, pos)
            )
        }
    }

    companion object {
        private const val ROOT = "root"
        private const val RESUME = "resume"
        private const val POD = "pod:"
        private const val HINT_PODCASTS = "hint_podcasts"
        private const val HINT_VIDEO = "hint_video"
    }
}
