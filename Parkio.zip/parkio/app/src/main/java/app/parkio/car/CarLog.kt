package app.parkio.car

import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Registro corto de lo que pasa en la pantalla del carro. Se ve en la opción "Diagnóstico" del carro. */
object CarLog {
    private val lines = ArrayDeque<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Synchronized
    fun add(msg: String) {
        Log.d("ParkioCar", msg)
        lines.addLast("${fmt.format(Date())} $msg")
        while (lines.size > 60) lines.removeFirst()
    }

    /** Las últimas [n] líneas, la más nueva primero. */
    @Synchronized
    fun last(n: Int): List<String> = lines.toList().takeLast(n).reversed()
}
