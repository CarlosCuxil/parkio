package app.parkio.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

class ApiException(val code: Int, message: String) : Exception(message)

/**
 * Cliente mínimo de YouTube Data API v3.
 * Con sesión iniciada usa el token de Google; sin sesión usa la API key (solo datos públicos).
 * Ojo con la cuota diaria: cada búsqueda cuesta 100 unidades de las 10.000 gratis al día.
 */
class YouTubeApi(
    private val tokenProvider: suspend () -> String?,
    private val apiKey: String,
) {
    private val region: String = Locale.getDefault().country.ifBlank { "US" }

    private suspend fun call(
        method: String,
        path: String,
        params: Map<String, String>,
        body: String? = null,
    ): JSONObject? {
        val token = tokenProvider()
        if (token == null && apiKey.isEmpty()) {
            throw ApiException(0, "Falta la API key de YouTube. Inicia sesión o configura el secreto YT_API_KEY.")
        }
        return withContext(Dispatchers.IO) {
            val query = buildString {
                params.forEach { (k, v) ->
                    if (isNotEmpty()) append('&')
                    append(k).append('=').append(URLEncoder.encode(v, "UTF-8"))
                }
                if (token == null) {
                    if (isNotEmpty()) append('&')
                    append("key=").append(URLEncoder.encode(apiKey, "UTF-8"))
                }
            }
            val conn = URL("https://www.googleapis.com/youtube/v3/$path?$query").openConnection() as HttpURLConnection
            try {
                conn.requestMethod = method
                conn.connectTimeout = 10_000
                conn.readTimeout = 15_000
                if (token != null) conn.setRequestProperty("Authorization", "Bearer $token")
                if (method == "POST") {
                    conn.doOutput = true
                    if (body != null) {
                        conn.setRequestProperty("Content-Type", "application/json")
                        conn.outputStream.use { it.write(body.toByteArray()) }
                    } else {
                        conn.setFixedLengthStreamingMode(0)
                    }
                }
                val code = conn.responseCode
                val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (code !in 200..299) throw ApiException(code, errorMessage(text, code))
                if (text.isBlank()) null else JSONObject(text)
            } finally {
                conn.disconnect()
            }
        }
    }

    private fun errorMessage(text: String, code: Int): String = try {
        JSONObject(text).getJSONObject("error").getString("message")
    } catch (e: Exception) {
        "Error $code de YouTube"
    }

    private fun parse(items: JSONArray?): List<Video> {
        if (items == null) return emptyList()
        val out = ArrayList<Video>()
        for (i in 0 until items.length()) {
            val o = items.optJSONObject(i) ?: continue
            val id = o.optString("id")
            val sn = o.optJSONObject("snippet") ?: continue
            if (id.isEmpty()) continue
            val th = sn.optJSONObject("thumbnails")
            val thumb = (th?.optJSONObject("medium") ?: th?.optJSONObject("high") ?: th?.optJSONObject("default"))
                ?.optString("url").orEmpty()
            val publishedAt = sn.optString("publishedAt")
            out += Video(
                id = id,
                title = sn.optString("title"),
                channel = sn.optString("channelTitle"),
                channelId = sn.optString("channelId"),
                thumb = thumb,
                duration = formatDuration(o.optJSONObject("contentDetails")?.optString("duration").orEmpty()),
                published = relativeTime(publishedAt),
                publishedAt = publishedAt,
            )
        }
        return out
    }

    private suspend fun hydrate(ids: List<String>): List<Video> {
        if (ids.isEmpty()) return emptyList()
        val order = ids.withIndex().associate { it.value to it.index }
        val json = call(
            "GET", "videos",
            mapOf("part" to "snippet,contentDetails", "id" to ids.take(50).joinToString(","))
        )
        return parse(json?.optJSONArray("items")).sortedBy { order[it.id] ?: Int.MAX_VALUE }
    }

    suspend fun popular(): List<Video> = parse(
        call(
            "GET", "videos",
            mapOf(
                "part" to "snippet,contentDetails",
                "chart" to "mostPopular",
                "regionCode" to region,
                "maxResults" to "25",
            )
        )?.optJSONArray("items")
    )

    suspend fun search(query: String): List<Video> {
        val json = call(
            "GET", "search",
            mapOf(
                "part" to "snippet",
                "type" to "video",
                "q" to query,
                "maxResults" to "25",
                "regionCode" to region,
                "relevanceLanguage" to "es",
                "safeSearch" to "moderate",
            )
        )
        val arr = json?.optJSONArray("items") ?: return emptyList()
        val ids = (0 until arr.length()).mapNotNull {
            arr.optJSONObject(it)?.optJSONObject("id")?.optString("videoId")?.takeIf { s -> s.isNotEmpty() }
        }
        return hydrate(ids)
    }

    suspend fun liked(): List<Video> = parse(
        call(
            "GET", "videos",
            mapOf("part" to "snippet,contentDetails", "myRating" to "like", "maxResults" to "30")
        )?.optJSONArray("items")
    )

    /** Últimos videos de tus suscripciones (usa la lista de subidas de cada canal: barato en cuota). */
    suspend fun subscriptionsFeed(): List<Video> {
        val subs = call(
            "GET", "subscriptions",
            mapOf("part" to "snippet", "mine" to "true", "maxResults" to "30", "order" to "relevance")
        )?.optJSONArray("items") ?: return emptyList()

        val channelIds = (0 until subs.length()).mapNotNull {
            subs.optJSONObject(it)?.optJSONObject("snippet")?.optJSONObject("resourceId")
                ?.optString("channelId")?.takeIf { s -> s.startsWith("UC") }
        }.take(12)

        val ids = coroutineScope {
            channelIds.map { ch ->
                async {
                    try {
                        val r = call(
                            "GET", "playlistItems",
                            mapOf(
                                "part" to "contentDetails",
                                "playlistId" to "UU" + ch.drop(2),
                                "maxResults" to "3",
                            )
                        )?.optJSONArray("items")
                        (0 until (r?.length() ?: 0)).mapNotNull { i ->
                            r?.optJSONObject(i)?.optJSONObject("contentDetails")
                                ?.optString("videoId")?.takeIf { s -> s.isNotEmpty() }
                        }
                    } catch (e: ApiException) {
                        emptyList()
                    }
                }
            }.awaitAll().flatten()
        }.distinct()

        return hydrate(ids).sortedByDescending { it.publishedAt }
    }

    /** Ids de los canales a los que estás suscrito (hasta 50). */
    private suspend fun subscribedChannelIds(): List<String> {
        val subs = call(
            "GET", "subscriptions",
            mapOf("part" to "snippet", "mine" to "true", "maxResults" to "50", "order" to "relevance")
        )?.optJSONArray("items") ?: return emptyList()
        return (0 until subs.length()).mapNotNull {
            subs.optJSONObject(it)?.optJSONObject("snippet")?.optJSONObject("resourceId")
                ?.optString("channelId")?.takeIf { s -> s.startsWith("UC") }
        }
    }

    /**
     * "Para ti". YouTube NO entrega por API el inicio personalizado de tu cuenta ni tu historial.
     * Se arma con lo que sí hay: los canales a los que estás suscrito y los canales de los videos que te
     * gustaron. En cada actualización se muestrean otros canales y otros videos, así que cambia.
     */
    suspend fun forYou(): List<Video> {
        val likedVideos = try {
            liked()
        } catch (e: ApiException) {
            emptyList()
        }
        val subscribed = try {
            subscribedChannelIds()
        } catch (e: ApiException) {
            emptyList()
        }
        val likedChannels = likedVideos.map { it.channelId }.filter { it.startsWith("UC") }
        val pool = (subscribed + likedChannels).distinct().shuffled().take(14)

        val ids = coroutineScope {
            pool.map { ch ->
                async {
                    try {
                        val r = call(
                            "GET", "playlistItems",
                            mapOf("part" to "contentDetails", "playlistId" to "UU" + ch.drop(2), "maxResults" to "12")
                        )?.optJSONArray("items")
                        (0 until (r?.length() ?: 0)).mapNotNull { i ->
                            r?.optJSONObject(i)?.optJSONObject("contentDetails")
                                ?.optString("videoId")?.takeIf { s -> s.isNotEmpty() }
                        }.shuffled().take(3)
                    } catch (e: ApiException) {
                        emptyList()
                    }
                }
            }.awaitAll().flatten()
        }.distinct().shuffled().take(45)

        val personal = hydrate(ids)
        val extra = try {
            popular().shuffled().take(if (personal.isEmpty()) 25 else 6)
        } catch (e: ApiException) {
            emptyList()
        }
        return (personal + extra).distinctBy { it.id }.shuffled()
    }

    suspend fun like(videoId: String) {
        call("POST", "videos/rate", mapOf("id" to videoId, "rating" to "like"))
    }

    suspend fun subscribe(channelId: String) {
        val body = JSONObject().put(
            "snippet",
            JSONObject().put(
                "resourceId",
                JSONObject().put("kind", "youtube#channel").put("channelId", channelId)
            )
        ).toString()
        call("POST", "subscriptions", mapOf("part" to "snippet"), body)
    }
}
