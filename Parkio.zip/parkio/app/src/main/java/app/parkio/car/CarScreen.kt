package app.parkio.car

import androidx.car.app.AppManager
import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.Template
import androidx.car.app.navigation.model.NavigationTemplate
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner

/** Pantalla vacía de plantilla: lo único que importa es la superficie que se dibuja debajo. */
class CarScreen(ctx: CarContext) : Screen(ctx) {

    private val renderer = CarSurfaceRenderer(ctx)

    init {
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onCreate(owner: LifecycleOwner) {
                carContext.getCarService(AppManager::class.java).setSurfaceCallback(renderer)
            }

            override fun onDestroy(owner: LifecycleOwner) {
                renderer.release()
            }
        })
    }

    override fun onGetTemplate(): Template {
        val exit = Action.Builder()
            .setTitle("Salir")
            .setOnClickListener { carContext.finishCarApp() }
            .build()
        return NavigationTemplate.Builder()
            .setActionStrip(ActionStrip.Builder().addAction(exit).build())
            .build()
    }
}
