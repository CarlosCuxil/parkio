package app.parkio.player

/**
 * Página que carga el reproductor OFICIAL incrustado de YouTube (IFrame Player API).
 * Es la forma permitida por los términos de YouTube: no se descarga ni se extrae el video.
 */
object PlayerHtml {
    const val BASE_URL = "https://www.youtube.com"

    fun page(videoId: String): String {
        val id = videoId.filter { it.isLetterOrDigit() || it == '_' || it == '-' }
        return """
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="referrer" content="strict-origin-when-cross-origin">
<style>html,body{margin:0;height:100%;background:#000;overflow:hidden}#p{width:100%;height:100%}#m{display:none;position:absolute;left:0;right:0;top:50%;transform:translateY(-50%);text-align:center;color:#fff;font:16px sans-serif;padding:0 24px}</style>
</head>
<body>
<div id="p"></div>
<div id="m"></div>
<script>
function st(s) { try { if (typeof Android !== 'undefined') Android.stage(s); } catch (e) {} }
</script>
<script src="https://www.youtube.com/iframe_api" onerror="st('error:script')"></script>
<script>
function onYouTubeIframeAPIReady() {
  st('api');
  new YT.Player('p', {
    videoId: '$id',
    width: '100%',
    height: '100%',
    playerVars: { autoplay: 1, playsinline: 1, rel: 0, modestbranding: 1, enablejsapi: 1, origin: '$BASE_URL' },
    events: {
      onReady: function () { st('ready'); },
      onStateChange: function (e) { if (e.data === 1) st('playing'); },
      onError: function (e) {
        var m = document.getElementById('m');
        m.textContent = 'Este video no se puede reproducir aquí (código ' + e.data + ').';
        m.style.display = 'block';
        st('error:' + e.data);
      }
    }
  });
}
</script>
</body>
</html>
""".trimIndent()
    }
}
