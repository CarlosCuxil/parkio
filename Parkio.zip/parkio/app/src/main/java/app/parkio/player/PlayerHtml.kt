package app.parkio.player

/**
 * Página que carga el reproductor OFICIAL incrustado de YouTube (IFrame Player API).
 * Es la forma permitida por los términos de YouTube: no se descarga ni se extrae el video.
 */
object PlayerHtml {
    const val BASE_URL = "https://www.youtube.com"

    fun page(videoId: String): String {
        val id = videoId.filter { it.isLetterOrDigit() || it == '_' || it == '-' }
        return """
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>html,body{margin:0;height:100%;background:#000;overflow:hidden}#p{width:100%;height:100%}</style>
</head>
<body>
<div id="p"></div>
<script src="https://www.youtube.com/iframe_api"></script>
<script>
function onYouTubeIframeAPIReady() {
  new YT.Player('p', {
    videoId: '$id',
    width: '100%',
    height: '100%',
    playerVars: { autoplay: 1, playsinline: 1, rel: 0, modestbranding: 1, enablejsapi: 1, origin: '$BASE_URL' }
  });
}
</script>
</body>
</html>
""".trimIndent()
    }
}
