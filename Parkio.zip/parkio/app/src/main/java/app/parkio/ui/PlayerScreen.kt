package app.parkio.ui

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.res.Configuration
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay
import app.parkio.car.CarLog
import app.parkio.data.Load
import app.parkio.data.Video
import app.parkio.player.PlayerHtml

@Composable
fun PlayerScreen(video: Video, vm: AppViewModel) {
    BackHandler { vm.close() }
    val ctx = LocalContext.current
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val signedIn by vm.signedIn.collectAsStateWithLifecycle()
    val feed by vm.feed.collectAsStateWithLifecycle()
    val results by vm.results.collectAsStateWithLifecycle()

    val related = remember(feed, results, video.id) {
        val a = (feed as? Load.Ok)?.value.orEmpty()
        val b = (results as? Load.Ok)?.value.orEmpty()
        (a + b).filter { it.id != video.id }.distinctBy { it.id }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Pk.Bg)
    ) {
        var status by remember(video.id) { mutableStateOf("Cargando reproductor…") }
        key(video.id) {
            YouTubeWebView(
                video.id,
                if (landscape) Modifier.fillMaxWidth().fillMaxHeight() else Modifier.fillMaxWidth().aspectRatio(16f / 9f),
                onStatus = { status = it },
            )
        }
        if (!landscape) {
            Text(
                status,
                color = Pk.Sub, fontSize = 11.sp,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            )
            LazyColumn(Modifier.weight(1f)) {
                item {
                    Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 14.dp)) {
                        Text(video.title, color = Pk.Text, fontSize = 18.sp, lineHeight = 23.sp, fontWeight = FontWeight.ExtraBold)
                        Text(video.published, color = Pk.Sub, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                    }
                }
                item {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Box(
                            Modifier.size(40.dp).clip(CircleShape).background(Pk.Chan),
                            contentAlignment = Alignment.Center,
                        ) { Text(video.channel.take(1).uppercase(), color = Pk.Text, fontWeight = FontWeight.ExtraBold) }
                        Text(
                            video.channel, color = Pk.Text, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f),
                        )
                        if (signedIn) {
                            Box(
                                Modifier
                                    .height(40.dp)
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(Pk.Text)
                                    .clickable { vm.subscribe(video) }
                                    .padding(horizontal = 18.dp),
                                contentAlignment = Alignment.Center,
                            ) { Text("Suscribirme", color = Pk.Bg, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold) }
                        }
                    }
                }
                item {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        modifier = Modifier.padding(bottom = 14.dp),
                    ) {
                        item {
                            ActionPill(Icons.Filled.ThumbUp, "Me gusta") {
                                if (signedIn) vm.like(video) else vm.message.tryEmit("Inicia sesión para dar me gusta")
                            }
                        }
                        item {
                            ActionPill(Icons.Filled.Share, "Compartir") {
                                val send = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, "https://youtu.be/${video.id}")
                                }
                                ctx.startActivity(Intent.createChooser(send, "Compartir").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            }
                        }
                        item { ActionPill(Icons.Filled.DirectionsCar, "Enviar al carro") { vm.sendToCar(video) } }
                    }
                }
                item {
                    Text(
                        "Siguientes",
                        color = Pk.Text, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    )
                }
                items(related) { v -> CompactRow(v) { vm.open(v) } }
                item { Spacer(Modifier.height(16.dp)) }
            }
        }
    }
}

@Composable
private fun ActionPill(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier
            .height(40.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Pk.Surface2)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(icon, contentDescription = null, tint = Pk.Text, modifier = Modifier.size(20.dp))
        Text(label, color = Pk.Text, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

/** Puente JS -> app: la página del reproductor avisa en qué etapa va (api, ready, playing, error:CÓDIGO). */
class PhoneBridge(private val onStage: (String) -> Unit) {
    private val main = Handler(Looper.getMainLooper())

    @JavascriptInterface
    fun stage(s: String) {
        main.post { onStage(s) }
    }
}

/**
 * Reproductor de YouTube dentro de un WebView. Primero intenta el reproductor oficial incrustado (IFrame API);
 * si YouTube no lo deja cargar (error, o no responde en 9 s) pasa solo a la web móvil de YouTube, que reproduce
 * cualquier video público con todos sus controles. Qué pasó se muestra en [onStatus] y queda en el registro.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun YouTubeWebView(videoId: String, modifier: Modifier, onStatus: (String) -> Unit = {}) {
    var web by remember { mutableStateOf<WebView?>(null) }
    var mode by remember(videoId) { mutableIntStateOf(0) }
    var ok by remember(videoId) { mutableStateOf(false) }
    val owner = LocalLifecycleOwner.current
    val status by rememberUpdatedState(onStatus)

    DisposableEffect(owner, web) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                // No se pausa el WebView al salir de la app: así el audio sigue sonando en segundo plano.
                Lifecycle.Event.ON_RESUME -> web?.onResume()
                else -> Unit
            }
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(videoId, mode) {
        if (mode == 0) {
            status("Cargando el reproductor de YouTube…")
            delay(9000)
            if (!ok) {
                CarLog.add("tel: el reproductor incrustado no respondió en 9 s")
                status("El reproductor incrustado no respondió. Uso la web de YouTube.")
                mode = 1
            }
        } else {
            status("Reproduciendo con la web de YouTube")
        }
    }

    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            WebView(ctx).apply {
                setBackgroundColor(android.graphics.Color.BLACK)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                addJavascriptInterface(
                    PhoneBridge { s ->
                        CarLog.add("tel: etapa $s")
                        if (s == "ready" || s == "playing") {
                            ok = true
                            status("Reproductor de YouTube listo")
                        } else if (s.startsWith("error:")) {
                            status("YouTube no deja reproducirlo incrustado (${s.removePrefix("error:")}). Uso la web de YouTube.")
                            mode = 1
                        }
                    },
                    "Android",
                )
                webChromeClient = FullscreenChromeClient(ctx)
                webViewClient = object : WebViewClient() {
                    // Dentro de youtube.com se puede navegar; salir a otros sitios se bloquea.
                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                        val host = request.url.host.orEmpty()
                        val allowed = host.endsWith("youtube.com") || host.endsWith("google.com") || host.endsWith("youtu.be")
                        return request.isForMainFrame && !allowed
                    }

                    override fun onPageFinished(view: WebView, url: String?) {
                        // Web móvil de YouTube: arranca en silencio ("Tap to unmute"); aquí se activa el sonido y se quita la barra superior.
                        if (url != null && url.contains("m.youtube.com/watch")) {
                            view.evaluateJavascript(PHONE_WATCH_SCRIPT, null)
                        }
                    }

                    override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                        if (request.isForMainFrame) {
                            CarLog.add("tel: error web ${error.errorCode} ${error.description}")
                            status("Error de red al cargar el reproductor: ${error.description}")
                        }
                    }
                }
                web = this
            }
        },
        update = { w ->
            if (w.tag != mode) {
                w.tag = mode
                if (mode == 0) {
                    w.loadDataWithBaseURL(PlayerHtml.BASE_URL, PlayerHtml.page(videoId), "text/html", "utf-8", null)
                } else {
                    val id = videoId.filter { it.isLetterOrDigit() || it == '_' || it == '-' }
                    w.loadUrl("https://m.youtube.com/watch?v=$id")
                }
            }
        },
        onRelease = {
            (it.webChromeClient as? FullscreenChromeClient)?.hideCustomView()
            it.stopLoading()
            it.destroy()
        },
    )
}

/** Deja usar el botón de pantalla completa del reproductor y manda los mensajes de consola al registro. */
class FullscreenChromeClient(private val ctx: Context) : WebChromeClient() {
    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null

    override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
        if (consoleMessage != null) CarLog.add("tel JS: ${consoleMessage.message()}")
        return true
    }

    override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
        val act = ctx.findActivity()
        if (act == null || view == null || customView != null) {
            callback?.onCustomViewHidden()
            return
        }
        customView = view
        customCallback = callback
        (act.window.decorView as FrameLayout).addView(
            view,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT),
        )
        WindowCompat.getInsetsController(act.window, act.window.decorView).hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onHideCustomView() {
        hideCustomView()
    }

    fun hideCustomView() {
        val view = customView ?: return
        val act = ctx.findActivity()
        if (act != null) {
            (act.window.decorView as FrameLayout).removeView(view)
            WindowCompat.getInsetsController(act.window, act.window.decorView).show(WindowInsetsCompat.Type.systemBars())
        }
        customView = null
        customCallback?.onCustomViewHidden()
        customCallback = null
    }
}

private fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}


/** Quita la barra y los avisos "Open App" de la web móvil de YouTube y activa el sonido (arranca en mute). */
private const val PHONE_WATCH_SCRIPT =
    "(function(){if(window.__pk)return;window.__pk=1;" +
        "var st=document.createElement('style');" +
        "st.textContent='ytm-mobile-topbar-renderer,.mobile-topbar-header,ytm-app-promo-renderer," +
        "ytm-mealbar-promo-renderer,ytm-open-app-banner,.open-app-button{display:none!important}';" +
        "(document.head||document.documentElement).appendChild(st);" +
        "var n=0;var t=setInterval(function(){n++;var v=document.querySelector('video');" +
        "if(v){try{var pl=document.querySelector('.html5-video-player');" +
        "if(pl&&pl.unMute){pl.unMute();if(pl.setVolume){pl.setVolume(100);}}}catch(e){}" +
        "if(v.muted||v.volume===0){v.muted=false;v.volume=1;}" +
        "var b=document.querySelector('.ytp-unmute,.ytp-unmute-inner,button[aria-label*=nmute]');" +
        "if(b){try{b.click();}catch(e){}}}" +
        "if(n>60){clearInterval(t);}},500);})();"
