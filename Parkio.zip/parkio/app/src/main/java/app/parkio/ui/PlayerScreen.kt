package app.parkio.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.content.res.Configuration
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.parkio.data.Load
import app.parkio.data.Video
import app.parkio.player.PlayerHtml

@Composable
fun PlayerScreen(video: Video, vm: AppViewModel) {
    BackHandler { vm.close() }
    val ctx = LocalContext.current
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val signedIn by vm.signedIn.collectAsStateWithLifecycle()
    val feed by vm.feed.collectAsStateWithLifecycle()
    val results by vm.results.collectAsStateWithLifecycle()

    val related = remember(feed, results, video.id) {
        val a = (feed as? Load.Ok)?.value.orEmpty()
        val b = (results as? Load.Ok)?.value.orEmpty()
        (a + b).filter { it.id != video.id }.distinctBy { it.id }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Pk.Bg)
    ) {
        key(video.id) {
            YouTubeWebView(
                video.id,
                if (landscape) Modifier.fillMaxWidth().fillMaxHeight() else Modifier.fillMaxWidth().aspectRatio(16f / 9f),
            )
        }
        if (!landscape) {
            LazyColumn(Modifier.weight(1f)) {
                item {
                    Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 14.dp)) {
                        Text(video.title, color = Pk.Text, fontSize = 18.sp, lineHeight = 23.sp, fontWeight = FontWeight.ExtraBold)
                        Text(video.published, color = Pk.Sub, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                    }
                }
                item {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Box(
                            Modifier.size(40.dp).clip(CircleShape).background(Pk.Chan),
                            contentAlignment = Alignment.Center,
                        ) { Text(video.channel.take(1).uppercase(), color = Pk.Text, fontWeight = FontWeight.ExtraBold) }
                        Text(
                            video.channel, color = Pk.Text, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f),
                        )
                        if (signedIn) {
                            Box(
                                Modifier
                                    .height(40.dp)
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(Pk.Text)
                                    .clickable { vm.subscribe(video) }
                                    .padding(horizontal = 18.dp),
                                contentAlignment = Alignment.Center,
                            ) { Text("Suscribirme", color = Pk.Bg, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold) }
                        }
                    }
                }
                item {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        modifier = Modifier.padding(bottom = 14.dp),
                    ) {
                        item {
                            ActionPill(Icons.Filled.ThumbUp, "Me gusta") {
                                if (signedIn) vm.like(video) else vm.message.tryEmit("Inicia sesión para dar me gusta")
                            }
                        }
                        item {
                            ActionPill(Icons.Filled.Share, "Compartir") {
                                val send = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, "https://youtu.be/${video.id}")
                                }
                                ctx.startActivity(Intent.createChooser(send, "Compartir").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            }
                        }
                        item { ActionPill(Icons.Filled.DirectionsCar, "Enviar al carro") { vm.sendToCar(video) } }
                    }
                }
                item {
                    Text(
                        "Siguientes",
                        color = Pk.Text, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    )
                }
                items(related) { v -> CompactRow(v) { vm.open(v) } }
                item { Spacer(Modifier.height(16.dp)) }
            }
        }
    }
}

@Composable
private fun ActionPill(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier
            .height(40.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Pk.Surface2)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(icon, contentDescription = null, tint = Pk.Text, modifier = Modifier.size(20.dp))
        Text(label, color = Pk.Text, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

/** Reproductor oficial de YouTube (IFrame API) dentro de un WebView. Se pausa al salir de la app. */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun YouTubeWebView(videoId: String, modifier: Modifier) {
    var web by remember { mutableStateOf<WebView?>(null) }
    val owner = LocalLifecycleOwner.current

    DisposableEffect(owner, web) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> web?.onPause()
                Lifecycle.Event.ON_RESUME -> web?.onResume()
                else -> Unit
            }
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }

    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            WebView(ctx).apply {
                setBackgroundColor(android.graphics.Color.BLACK)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                webChromeClient = WebChromeClient()
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = true
                }
                loadDataWithBaseURL(PlayerHtml.BASE_URL, PlayerHtml.page(videoId), "text/html", "utf-8", null)
                web = this
            }
        },
        onRelease = {
            it.stopLoading()
            it.destroy()
        },
    )
}
