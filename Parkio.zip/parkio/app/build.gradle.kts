plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "app.parkio"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.parkio"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "0.2.1"
        // La API key de YouTube Data API v3 entra por variable de entorno (secreto de GitHub YT_API_KEY).
        val key = System.getenv("YT_API_KEY") ?: ""
        buildConfigField("String", "YT_API_KEY", "\"$key\"")
    }

    // Llave fija para que el SHA-1 no cambie entre compilaciones (lo necesita el login de Google).
    // Es una llave personal para instalar el APK por tu cuenta, no para publicar en Play.
    signingConfigs {
        create("parkio") {
            storeFile = file("parkio.keystore")
            storePassword = "parkio-personal"
            keyAlias = "parkio"
            keyPassword = "parkio-personal"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("parkio")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("parkio")
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    // Que una advertencia de lint no bloquee el APK personal.
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.runtime:runtime-livedata")

    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")
    implementation("io.coil-kt:coil-compose:2.7.0")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.8.1")

    implementation("com.google.android.gms:play-services-auth:21.2.0")
    implementation("androidx.car.app:app:1.4.0")

    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-session:1.4.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-guava:1.8.1")
}
