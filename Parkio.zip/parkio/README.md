# Parkio

App de video estilo YouTube para el teléfono, con pantalla propia para Android Auto que **solo reproduce video con el carro estacionado**.

- Teléfono: Inicio, Explorar, Suscripciones, Biblioteca, reproductor, login con Google, "Enviar al carro".
- Carro: menú con Cola, Suscripciones, Populares, **Prueba de pantalla** (barras animadas con FPS) y **Diagnóstico**. Se maneja **con la perilla (Commander)**: el Mazda Connect no usa la pantalla táctil con Android Auto. Las listas son nativas de Android Auto; el video y la prueba se dibujan en la superficie y llevan botones (−10 s, pausa/play, +30 s, Salir) en la barra de acciones.
- Reproducción: reproductor oficial incrustado de YouTube (IFrame). No descarga ni extrae video.

## Podcasts con el carro en marcha (solo audio)

- Pestaña **Podcasts** en el teléfono: busca, suscríbete y reproduce. Los feeds son RSS (audio abierto, sin YouTube).
- Parkio también aparece en el **lanzador de música de Android Auto**: ves "Continuar escuchando" y tus podcasts, con controles grandes.
- Sigue sonando con la pantalla apagada y reanuda cada episodio donde lo dejaste.
- Esto es independiente del video: sirve manejando. El video sigue bloqueado salvo estacionado.
- Como se instala por APK, Android Auto también necesita **Fuentes desconocidas** activado para ver esta parte.

## Instalación (una sola vez)

1. **GitHub**: crea un repo privado, sube todo el contenido de esta carpeta (incluye `.github/` y `app/parkio.keystore`).
2. **Google Cloud** (console.cloud.google.com), un proyecto nuevo:
   - Habilita **YouTube Data API v3**.
   - *Credenciales → Crear → Clave de API*. Cópiala.
   - *Pantalla de consentimiento OAuth*: tipo Externo, estado **Pruebas**, agrega tu correo de Google como usuario de prueba y el permiso `.../auth/youtube`.
   - *Credenciales → ID de cliente OAuth → Android*: paquete `app.parkio`, huella SHA-1:
     `33:73:8F:BF:02:27:66:75:25:93:DC:36:28:7A:12:F7:E2:AA:85:A2`
3. **Secreto**: en el repo, *Settings → Secrets and variables → Actions → New secret* → nombre `YT_API_KEY`, valor = la clave de API.
4. **Compilar**: pestaña *Actions → Compilar APK → Run workflow*. Al terminar, descarga el artefacto `Parkio-APK` y desbloquea el `.apk`.
5. **Instalar** el APK en el teléfono. Al abrir, acepta el permiso de ubicación (solo se usa para saber si el carro está detenido).

## Android Auto

1. App Android Auto → Ajustes → toca **Versión** 10 veces → menú ⋮ → **Ajustes de desarrollador** → activa **Fuentes desconocidas**.
2. Conecta el teléfono al carro. Abre el lanzador de apps de Android Auto: debe aparecer **Parkio**.
3. Primero entra a **Prueba de pantalla** y mira los FPS. Si se ve fluido, el video es viable en tu pantalla. Si no se ve nada, entra a **Diagnóstico**.

## Regla de seguridad (no se salta)

El video se bloquea siempre que el GPS del teléfono marque velocidad ≥ 1 m/s o no haya señal reciente. Se desbloquea tras 3 s detenido. Sin GPS (garaje) aparece el botón manual "Estoy estacionado", solo si no hubo movimiento en el último minuto, y se anula al detectar movimiento.

## Límites conocidos

- Google Play no aceptaría esta app de video en Android Auto; funciona por APK con "Fuentes desconocidas".
- Si Android Auto o el Mazda Connect no entregan la superficie, la app del carro no abrirá; el teléfono sigue funcionando.
- Con el Mazda Connect no se usa la pantalla táctil: todo con la perilla. Los botones del video aparecen al mover la perilla.
- Si la pantalla del carro sale negra: carro → **Diagnóstico** muestra el registro, y ahí mismo puedes cambiar el **Modo de dibujo** a «compatible».
- Algunos videos no permiten reproducirse incrustados: Parkio pasa solo a la web de YouTube para esos (y si el reproductor incrustado no responde). En Biblioteca → Diagnóstico queda el registro de qué pasó.
- Cuota gratis de YouTube Data API: 10.000 unidades al día; cada búsqueda cuesta 100.
- Con la pantalla de consentimiento en "Pruebas", Google pide volver a iniciar sesión cada ~7 días.
- YouTube no entrega por API el inicio personalizado ni el historial. Con sesión iniciada, «Para ti» se arma con tus suscripciones y los canales de tus Me gusta, y cambia al deslizar para actualizar.
- Código escrito sin poder compilarlo en el entorno de desarrollo: el primer build puede pedir ajustes menores.
