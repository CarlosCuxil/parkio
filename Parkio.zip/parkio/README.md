# Parkio

App de video estilo YouTube para el teléfono, con pantalla propia para Android Auto que **solo reproduce video con el carro estacionado**.

- Teléfono: Inicio, Explorar, Suscripciones, Biblioteca, reproductor, login con Google, "Enviar al carro".
- Carro (800x480): Cola, Suscripciones, Populares y una **Prueba de pantalla** (barras animadas con FPS) para comprobar si el Mazda Connect aguanta movimiento fluido antes de confiar en el video.
- Reproducción: reproductor oficial incrustado de YouTube (IFrame). No descarga ni extrae video.

## Podcasts con el carro en marcha (solo audio)

- Pestaña **Podcasts** en el teléfono: busca, suscríbete y reproduce. Los feeds son RSS (audio abierto, sin YouTube).
- Parkio también aparece en el **lanzador de música de Android Auto**: ves "Continuar escuchando" y tus podcasts, con controles grandes.
- Sigue sonando con la pantalla apagada y reanuda cada episodio donde lo dejaste.
- Esto es independiente del video: sirve manejando. El video sigue bloqueado salvo estacionado.
- Como se instala por APK, Android Auto también necesita **Fuentes desconocidas** activado para ver esta parte.

## Instalación (una sola vez)

1. **GitHub**: crea un repo privado, sube todo el contenido de esta carpeta (incluye `.github/` y `app/parkio.keystore`).
2. **Google Cloud** (console.cloud.google.com), un proyecto nuevo:
   - Habilita **YouTube Data API v3**.
   - *Credenciales → Crear → Clave de API*. Cópiala.
   - *Pantalla de consentimiento OAuth*: tipo Externo, estado **Pruebas**, agrega tu correo de Google como usuario de prueba y el permiso `.../auth/youtube`.
   - *Credenciales → ID de cliente OAuth → Android*: paquete `app.parkio`, huella SHA-1:
     `33:73:8F:BF:02:27:66:75:25:93:DC:36:28:7A:12:F7:E2:AA:85:A2`
3. **Secreto**: en el repo, *Settings → Secrets and variables → Actions → New secret* → nombre `YT_API_KEY`, valor = la clave de API.
4. **Compilar**: pestaña *Actions → Compilar APK → Run workflow*. Al terminar, descarga el artefacto `Parkio-APK` y desbloquea el `.apk`.
5. **Instalar** el APK en el teléfono. Al abrir, acepta el permiso de ubicación (solo se usa para saber si el carro está detenido).

## Android Auto

1. App Android Auto → Ajustes → toca **Versión** 10 veces → menú ⋮ → **Ajustes de desarrollador** → activa **Fuentes desconocidas**.
2. Conecta el teléfono al carro. Abre el lanzador de apps de Android Auto: debe aparecer **Parkio**.
3. Primero entra a **Prueba** y mira los FPS. Si se ve fluido, el video es viable en tu pantalla.

## Regla de seguridad (no se salta)

El video se bloquea siempre que el GPS del teléfono marque velocidad ≥ 1 m/s o no haya señal reciente. Se desbloquea tras 3 s detenido. Sin GPS (garaje) aparece el botón manual "Estoy estacionado", solo si no hubo movimiento en el último minuto, y se anula al detectar movimiento.

## Límites conocidos

- Google Play no aceptaría esta app de video en Android Auto; funciona por APK con "Fuentes desconocidas".
- Si Android Auto o el Mazda Connect no entregan la superficie, la app del carro no abrirá; el teléfono sigue funcionando.
- Los toques funcionan con la pantalla táctil (el Mazda la habilita al estar detenido). El dial/perilla no está mapeado.
- Algunos videos no permiten reproducirse incrustados.
- Cuota gratis de YouTube Data API: 10.000 unidades al día; cada búsqueda cuesta 100.
- Con la pantalla de consentimiento en "Pruebas", Google pide volver a iniciar sesión cada ~7 días.
- Las recomendaciones personalizadas de YouTube no están en la API: el Inicio muestra populares o la categoría elegida.
- Código escrito sin poder compilarlo en el entorno de desarrollo: el primer build puede pedir ajustes menores.
